"""
SurvivalGAN package — conditional synthetic survival data generation
====================================================================

Public API:
    from survgan import SurvivalGANModel, prepare_data

    # Training
    df_train, df_test, meta = prepare_data("msk_impact_50K.csv", out_dir="prepped/")
    model = SurvivalGANModel(
        covariates=["Age at Diagnosis", "Sex", "Mutation Count"],   # subset
        cancer_type_column="Cancer Type",                            # conditional
        time_column="time",
        status_column="status",
    )
    model.fit(df_train, n_iter=2500)
    model.save_pt("model.pt")

    # Inference
    model = SurvivalGANModel.load_pt("model.pt")
    syn_df = model.generate(n_samples=500, cancer_type="Breast Cancer")
"""

__version__ = "1.0.0"

from .preprocessing import prepare_data
from .model import SurvivalGANModel
from .utils import seed_everything, setup_device

__all__ = [
    "prepare_data",
    "SurvivalGANModel",
    "seed_everything",
    "setup_device",
    "__version__",
]
