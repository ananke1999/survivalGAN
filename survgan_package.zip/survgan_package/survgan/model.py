"""
SurvivalGANModel — high-level API for cancer-type-conditional survival data
synthesis on MSK-IMPACT.

This replaces the SurvivalPipeline class in the user's original survGAN.py.
Key differences from the original:

  1. CANCER-TYPE CONDITIONING (not the paper's full survival conditional).
     The user specified Q1 = "One conditional model that takes Cancer Type as
     an input condition (1 .pt file)". So the GAN's conditional vector is the
     one-hot encoding of Cancer Type. At generate time the user supplies a
     cancer type string and gets back samples of that type.

  2. SUBSET-OF-COVARIATES TRAINING (Q3 = "keep them in the preprocessed CSV
     but only feed the chosen subset to the GAN as features"). The model
     accepts a `covariates` list at construction time and trains only on
     those + time + status. Cancer Type is the conditional, not a covariate.

  3. .pt SAVE/LOAD via torch.save (torch.save uses pickle internally so this
     works for arbitrary Python objects including XGBoost and sklearn). The
     bundle is fully self-contained — generator + discriminator weights, all
     fitted encoders, the DeepHit TTE, and the censoring predictor — so
     loading the .pt is enough to call .generate(...) end to end.
"""

import logging
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Union

import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier

from .pipeline import TabularGAN
from .tte import LocalSurvivalFunctionTTE
from .constraints import (
    build_constraint_map,
    enforce_physical_constraints,
    match_real_precision,
)


log = logging.getLogger(__name__)


# =========================================================================== #
#  Config — all hyperparameters in one place                                   #
# =========================================================================== #

@dataclass
class SurvivalGANConfig:
    """All hyperparameters — modify here, not in the code below."""
    # ---- GAN architecture ----
    n_iter: int = 2500
    batch_size: int = 256
    n_units_latent: int = 250

    generator_n_layers_hidden: int = 3
    generator_n_units_hidden: int = 250
    generator_nonlin: str = "tanh"
    generator_dropout: float = 0.1
    generator_residual: bool = True
    generator_batch_norm: bool = False
    generator_lr: float = 1e-3
    generator_weight_decay: float = 1e-3
    generator_opt_betas: tuple = (0.5, 0.999)

    discriminator_n_layers_hidden: int = 2
    discriminator_n_units_hidden: int = 250
    discriminator_nonlin: str = "leaky_relu"
    discriminator_n_iter: int = 5
    discriminator_dropout: float = 0.1
    discriminator_batch_norm: bool = False
    discriminator_lr: float = 1e-3
    discriminator_weight_decay: float = 1e-3
    discriminator_opt_betas: tuple = (0.5, 0.999)

    # ---- GAN training ----
    clipping_value: int = 1
    lambda_gradient_penalty: float = 10.0
    lambda_identifiability_penalty: float = 0.1

    # ---- Encoder ----
    encoder_max_clusters: int = 10

    # ---- TTE ----
    tte_n_estimators: int = 500
    tte_max_depth: int = 6
    tte_add_residual_noise: bool = True
    tte_noise_scale: float = 0.5
    tte_clamp_margin: float = 0.05

    # ---- System ----
    seed: int = 42


# =========================================================================== #
#  SurvivalGANModel — the high-level API                                       #
# =========================================================================== #

class SurvivalGANModel:
    """
    Cancer-type-conditional SurvivalGAN.

    Workflow:
        # Train
        model = SurvivalGANModel(
            covariates=["Age at Diagnosis", "Sex", ...],
            cancer_type_column="Cancer Type",
            time_column="time",
            status_column="status",
            cancer_type_label_encoder=metadata["label_encoders"]["Cancer Type"],
            column_metadata=metadata["column_metadata"],
        )
        model.fit(df_train, n_iter=2500)
        model.save_pt("model.pt")

        # Inference
        model = SurvivalGANModel.load_pt("model.pt")
        syn = model.generate(n_samples=500, cancer_type="Breast Cancer")

    The covariates list selects WHICH features the GAN learns. Cancer Type is
    always the conditional and is not in the covariates list. Time and status
    are required outputs and are also not in the covariates list.
    """

    BUNDLE_VERSION = "1.0"

    def __init__(
        self,
        covariates: Sequence[str],
        cancer_type_column: str = "Cancer Type",
        time_column: str = "time",
        status_column: str = "status",
        cancer_type_label_encoder: Optional[LabelEncoder] = None,
        column_metadata: Optional[Dict[str, Dict]] = None,
        config: Optional[SurvivalGANConfig] = None,
        device: str = "cpu",
    ):
        self.covariates: List[str] = list(covariates)
        self.cancer_type_column = cancer_type_column
        self.time_column = time_column
        self.status_column = status_column
        self.cancer_type_label_encoder = cancer_type_label_encoder
        self.column_metadata = column_metadata or {}
        self.cfg = config or SurvivalGANConfig()
        self.device = device

        # Validate
        if cancer_type_column in self.covariates:
            raise ValueError(
                f"'{cancer_type_column}' is the conditional and cannot also be a covariate."
            )
        if time_column in self.covariates or status_column in self.covariates:
            raise ValueError(
                f"'{time_column}' and '{status_column}' are targets and cannot be covariates."
            )

        # Will be set during fit()
        self.gan: Optional[TabularGAN] = None
        self.tte_model: Optional[LocalSurvivalFunctionTTE] = None
        self.censoring_predictor: Optional[XGBClassifier] = None
        self.training_columns: Optional[List[str]] = None  # ordered list of cols actually trained on
        self.cancer_type_classes: Optional[np.ndarray] = None
        self._fitted = False

    # ------------------------------------------------------------------ #
    #  FIT                                                                #
    # ------------------------------------------------------------------ #

    def fit(self, df: pd.DataFrame, n_iter: Optional[int] = None) -> "SurvivalGANModel":
        """Train the conditional GAN + TTE + censoring predictor."""
        if n_iter is not None:
            self.cfg.n_iter = n_iter

        self._validate_input_df(df)

        # Build the modeling-space DataFrame: covariates + time + status.
        # Cancer Type is split off and used as the conditional.
        cancer_type_series = df[self.cancer_type_column].copy()
        df_model = df[self.covariates + [self.time_column, self.status_column]].copy()
        E = df_model[self.status_column]
        T = df_model[self.time_column]
        Xcov = df_model[self.covariates]

        log.info(
            f"Training SurvivalGAN | covariates={len(self.covariates)} "
            f"({self.covariates}) | n_train={len(df_model)} | "
            f"event_rate={E.mean():.3f} | "
            f"unique_cancer_types={cancer_type_series.nunique()}"
        )

        # Record cancer type classes (these are the integer codes from the
        # label encoder; the encoder itself maps strings ↔ codes).
        self.cancer_type_classes = np.sort(cancer_type_series.unique())

        # ---- 1. Train TTE on the chosen covariate subset ----
        log.info("Training TTE model (DeepHit + XGBoost log-T regressor) ...")
        self.tte_model = LocalSurvivalFunctionTTE(
            device=self.device,
            n_estimators=self.cfg.tte_n_estimators,
            max_depth=self.cfg.tte_max_depth,
            add_residual_noise=self.cfg.tte_add_residual_noise,
            noise_scale=self.cfg.tte_noise_scale,
            clamp_margin=self.cfg.tte_clamp_margin,
        )
        self.tte_model.fit(Xcov, T, E)

        # ---- 2. Train conditional TabularGAN ----
        # Conditional = Cancer Type (1D series, OneHot-encoded inside TabularGAN).
        log.info(
            f"Training conditional TabularGAN | df_model.shape={df_model.shape} | "
            f"conditional=Cancer Type ({cancer_type_series.nunique()} classes) "
            f"| n_iter={self.cfg.n_iter} | batch_size={self.cfg.batch_size} ..."
        )

        self.gan = TabularGAN(
            X=df_model,
            n_units_latent=self.cfg.n_units_latent,
            cond=cancer_type_series,
            encoder_max_clusters=self.cfg.encoder_max_clusters,
            device=self.device,
            generator_n_layers_hidden=self.cfg.generator_n_layers_hidden,
            generator_n_units_hidden=self.cfg.generator_n_units_hidden,
            generator_nonlin=self.cfg.generator_nonlin,
            generator_nonlin_out_discrete="softmax",
            generator_nonlin_out_continuous="none",
            generator_n_iter=self.cfg.n_iter,
            generator_batch_norm=self.cfg.generator_batch_norm,
            generator_dropout=self.cfg.generator_dropout,
            generator_lr=self.cfg.generator_lr,
            generator_weight_decay=self.cfg.generator_weight_decay,
            generator_residual=self.cfg.generator_residual,
            generator_opt_betas=self.cfg.generator_opt_betas,
            generator_extra_penalties=["identifiability_penalty"],
            discriminator_n_layers_hidden=self.cfg.discriminator_n_layers_hidden,
            discriminator_n_units_hidden=self.cfg.discriminator_n_units_hidden,
            discriminator_nonlin=self.cfg.discriminator_nonlin,
            discriminator_n_iter=self.cfg.discriminator_n_iter,
            discriminator_batch_norm=self.cfg.discriminator_batch_norm,
            discriminator_dropout=self.cfg.discriminator_dropout,
            discriminator_lr=self.cfg.discriminator_lr,
            discriminator_weight_decay=self.cfg.discriminator_weight_decay,
            discriminator_opt_betas=self.cfg.discriminator_opt_betas,
            batch_size=self.cfg.batch_size,
            random_state=self.cfg.seed,
            clipping_value=self.cfg.clipping_value,
            lambda_gradient_penalty=self.cfg.lambda_gradient_penalty,
            lambda_identifiability_penalty=self.cfg.lambda_identifiability_penalty,
        )
        self.gan.fit(df_model, cond=cancer_type_series)

        # ---- 3. Train censoring predictor (used for "covariate_dependent" censoring) ----
        log.info("Training censoring predictor (XGBoost) ...")
        xgb_params = {"tree_method": "approx", "n_jobs": 2, "verbosity": 0,
                      "max_depth": 3, "random_state": self.cfg.seed}
        self.censoring_predictor = XGBClassifier(**xgb_params).fit(Xcov, E)

        self.training_columns = df_model.columns.tolist()
        self._fitted = True
        return self

    # ------------------------------------------------------------------ #
    #  GENERATE                                                           #
    # ------------------------------------------------------------------ #

    def generate(
        self,
        n_samples: int,
        cancer_type: Optional[Union[str, int, Sequence]] = None,
        seed: Optional[int] = None,
        enforce_constraints: bool = True,
        match_precision: bool = True,
        real_df_for_precision: Optional[pd.DataFrame] = None,
        decode_cancer_type: bool = False,
    ) -> pd.DataFrame:
        """
        Generate synthetic patients, optionally conditioned on a cancer type.

        Parameters
        ----------
        n_samples : int
            Number of synthetic rows to produce.
        cancer_type : str | int | sequence | None
            If a string: the cancer type name (must be a known class). All rows
            will have that cancer type.
            If an int: the integer code from the label encoder. Same effect.
            If a sequence: per-row cancer types; len must equal n_samples.
            If None: cancer types are sampled in proportion to the training
            distribution (the GAN's default behavior).
        seed : int | None
            If set, reseed numpy + torch before generating.
        enforce_constraints : bool
            Run physical-constraint enforcement (clip to bounds, cast ints).
        match_precision : bool
            Snap synthetic numerics to match real precision (requires
            real_df_for_precision).
        real_df_for_precision : pd.DataFrame | None
            Real data used for precision matching. If None, precision matching
            is skipped.
        decode_cancer_type : bool
            If True, output the Cancer Type column as human-readable strings
            ("Breast Cancer", ...). If False (default), output as integer
            codes — this matches the format of the preprocessed real CSVs
            and is required for evaluate_synthetic_data.py to work without
            type-mismatch errors. The HF endpoint flips this to True for
            JSON-friendly output.

        Returns
        -------
        pd.DataFrame  with columns = covariates + time + status + Cancer Type.
        """
        if not self._fitted:
            raise RuntimeError("Model is not fitted yet — call fit() first or load a checkpoint.")

        if seed is not None:
            np.random.seed(seed)
            torch.manual_seed(seed)

        # Resolve the conditional vector
        cond_codes = self._resolve_cancer_type_codes(cancer_type, n_samples)

        # Generate covariates + time + status from the conditional GAN
        log.info(f"Generating {n_samples} samples (cancer_type={cancer_type}) ...")
        generated = self.gan.generate(n_samples, cond=cond_codes)

        # ---- Replace GAN-emitted E with covariate-dependent censoring ----
        # NOTE: this MUST happen BEFORE TTE prediction, so the TTE model
        # conditions on the corrected E rather than the GAN's raw output.
        # This matches the original SurvivalPipeline.generate() ordering.
        #
        # We use predict_proba + sampling rather than predict(). The default
        # 0.5 hard threshold collapses the event rate when synthetic
        # covariates are slightly off the predictor's training distribution
        # (which is common with under-trained GANs). Sampling from the
        # calibrated probabilities preserves the marginal event rate.
        if self.censoring_predictor is not None:
            cov_cols = [c for c in self.covariates if c in generated.columns]
            try:
                probs = self.censoring_predictor.predict_proba(generated[cov_cols])[:, 1]
                generated[self.status_column] = (
                    np.random.uniform(size=len(probs)) < probs
                ).astype(int)
                log.info(
                    f"Censoring sampled from predict_proba: "
                    f"mean P(event)={probs.mean():.3f}, "
                    f"empirical event rate={generated[self.status_column].mean():.3f}"
                )
            except (AttributeError, IndexError):
                # Predictor doesn't support predict_proba (some sklearn variants)
                # or single-class training data — fall back to hard predict.
                log.warning("predict_proba unavailable; falling back to predict()")
                generated[self.status_column] = self.censoring_predictor.predict(
                    generated[cov_cols]
                )

        # ---- Replace GAN-emitted T with TTE-predicted T ----
        # The SurvivalGAN paper recommends predicting T from a separate TTE
        # model rather than letting the GAN emit it directly. We pass the
        # post-censoring E so TTE conditions on the corrected event indicator.
        if self.tte_model is not None and self.time_column in generated.columns:
            generated = generated.drop(columns=[self.time_column])
            cov_cols = [c for c in generated.columns if c != self.status_column]
            generated[self.time_column] = self.tte_model.predict_any(
                generated[cov_cols],
                generated[self.status_column],
            ).values

        # ---- Re-attach Cancer Type as a column ----
        # Default: integer codes (matches the preprocessed real CSV format,
        # required for evaluate_synthetic_data.py). Set decode_cancer_type=True
        # for human-readable strings (used by the HF endpoint).
        ct_col = self._resolve_output_cancer_type(cond_codes, decode=decode_cancer_type)
        generated[self.cancer_type_column] = ct_col

        # ---- Reorder columns: covariates + time + status + cancer_type ----
        out_cols = [c for c in self.training_columns if c in generated.columns]
        out_cols.append(self.cancer_type_column)
        generated = generated[out_cols]

        # ---- Post-generation precision matching ----
        if match_precision and real_df_for_precision is not None:
            generated, _ = match_real_precision(
                real_df_for_precision, generated,
                skip_cols={self.time_column, self.status_column},
            )

        # ---- Post-generation physical-constraint enforcement ----
        if enforce_constraints:
            real_for_inference = real_df_for_precision if real_df_for_precision is not None else generated
            constraint_map = build_constraint_map(real_for_inference, self.column_metadata)
            generated, report = enforce_physical_constraints(
                real_for_inference, generated, constraint_map,
            )
            n_modified = sum(
                v["n_below"] + v["n_above"] + v["n_rounded"]
                for v in report.values()
            )
            if n_modified > 0:
                log.info(f"Physical constraints: modified {n_modified} values")

        # ---- Final time-column sanity clip ----
        if (self.tte_model is not None and self.tte_model._T_min is not None
                and self.time_column in generated.columns):
            generated[self.time_column] = generated[self.time_column].clip(
                lower=max(self.tte_model._T_min, 1e-3),
                upper=self.tte_model._T_max,
            )

        return generated

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                   #
    # ------------------------------------------------------------------ #

    def _validate_input_df(self, df: pd.DataFrame) -> None:
        required = self.covariates + [
            self.time_column, self.status_column, self.cancer_type_column,
        ]
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(
                f"Input DataFrame is missing required columns: {missing}\n"
                f"Have: {df.columns.tolist()}"
            )
        if df[self.status_column].isna().any() or df[self.time_column].isna().any():
            raise ValueError("time / status must be non-null")
        if not (df[self.time_column] > 0).all():
            raise ValueError("time must be strictly positive")
        if not df[self.status_column].isin([0, 1]).all():
            raise ValueError("status must be 0 or 1")

    def _resolve_cancer_type_codes(
        self,
        cancer_type: Optional[Union[str, int, Sequence]],
        n_samples: int,
    ) -> Optional[pd.Series]:
        """Return a length-n_samples Series of integer-coded cancer types,
        or None to let the GAN sample from its training-time distribution."""
        if cancer_type is None:
            return None

        # Per-row sequence
        if isinstance(cancer_type, (list, np.ndarray, pd.Series)):
            if len(cancer_type) != n_samples:
                raise ValueError(
                    f"len(cancer_type) ({len(cancer_type)}) != n_samples ({n_samples})"
                )
            codes = [self._coerce_cancer_type_to_code(c) for c in cancer_type]
            return pd.Series(codes, name=self.cancer_type_column)

        # Single string or int → broadcast
        code = self._coerce_cancer_type_to_code(cancer_type)
        return pd.Series([code] * n_samples, name=self.cancer_type_column)

    def _coerce_cancer_type_to_code(self, ct: Union[str, int, np.integer]) -> int:
        """Turn a cancer-type string or int into the integer code the GAN saw."""
        if isinstance(ct, (int, np.integer)):
            code = int(ct)
            # cancer_type_classes is None until fit() runs. In normal usage
            # this method is only reached via generate(), which gates on
            # _fitted first, so this defensive check just guards against
            # direct calls on an unfit model.
            if self.cancer_type_classes is not None and code not in self.cancer_type_classes:
                raise ValueError(
                    f"Cancer type code {code} not seen in training. "
                    f"Known codes: {self.cancer_type_classes.tolist()}"
                )
            return code

        if isinstance(ct, str):
            if self.cancer_type_label_encoder is None:
                raise ValueError(
                    "Cancer type provided as string but no label encoder is "
                    "attached to this model. Either pass an integer code, or "
                    "construct the model with cancer_type_label_encoder=..."
                )
            le = self.cancer_type_label_encoder
            if ct not in set(le.classes_):
                raise ValueError(
                    f"Cancer type '{ct}' not in label encoder classes. Known: "
                    f"{le.classes_.tolist()}"
                )
            return int(le.transform([ct])[0])

        raise TypeError(f"Unsupported cancer_type type: {type(ct)}")

    def _resolve_output_cancer_type(
        self, cond_codes: Optional[pd.Series], decode: bool = False,
    ) -> pd.Series:
        """Return a Series of cancer-type values for the synthetic output.

        If `decode=True` and a label encoder is attached, returns string names
        ("Breast Cancer", ...). Otherwise returns the integer codes.
        """
        if cond_codes is None:
            # GAN sampled internally from training distribution; recover its
            # picks from the GAN's stored conditional. This is rare in normal
            # usage (callers usually pass cancer_type explicitly).
            if self.gan.model._original_cond is not None:
                # _original_cond is one-hot encoded — recover indices
                cond_oh = self.gan.model._original_cond.detach().cpu().numpy()
                # The OneHotEncoder used by TabularGAN sorts classes; recover
                # them from cond_encoder.categories_[0]
                classes = self.gan.cond_encoder.categories_[0]
                idx = cond_oh.argmax(axis=1)
                codes = np.asarray(classes[idx], dtype=int)
            else:
                codes = np.zeros(0, dtype=int)
        else:
            codes = np.asarray(cond_codes.values, dtype=int)

        if decode and self.cancer_type_label_encoder is not None:
            try:
                strings = self.cancer_type_label_encoder.inverse_transform(codes)
                return pd.Series(strings)
            except Exception as e:
                log.warning(
                    f"Could not decode cancer_type codes back to strings ({e}); "
                    f"returning integer codes instead."
                )
        return pd.Series(codes)

    # ------------------------------------------------------------------ #
    #  SAVE / LOAD                                                        #
    # ------------------------------------------------------------------ #

    def save_pt(self, path: Union[str, Path]) -> None:
        """Save the full model bundle to a .pt file via torch.save.

        torch.save uses pickle internally, so this works for arbitrary Python
        objects (XGBoost, sklearn BayesianGMM, etc.). The bundle is fully
        self-contained: load it on any machine with this package installed and
        you can immediately call .generate(...).
        """
        if not self._fitted:
            raise RuntimeError("Cannot save an unfitted model.")

        bundle = {
            "version": self.BUNDLE_VERSION,
            "config":  asdict(self.cfg),
            "covariates": self.covariates,
            "cancer_type_column": self.cancer_type_column,
            "time_column": self.time_column,
            "status_column": self.status_column,
            "cancer_type_classes": self.cancer_type_classes,
            "cancer_type_label_encoder": self.cancer_type_label_encoder,
            "column_metadata": self.column_metadata,
            "training_columns": self.training_columns,
            "device": "cpu",  # always saved as CPU; user can move at load time
            # Full model objects (pickled by torch.save).
            # TabularGAN holds the GAN nn.Module + encoders + cond_encoder.
            # tte_model holds DeepHit + XGBoost + log-T bounds.
            # censoring_predictor is XGBClassifier.
            "gan": _to_cpu(self.gan),
            "tte_model": self.tte_model,
            "censoring_predictor": self.censoring_predictor,
        }

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(bundle, path)
        size_mb = path.stat().st_size / 1e6
        log.info(f"Saved SurvivalGANModel bundle → {path} ({size_mb:.1f} MB)")

    @classmethod
    def load_pt(cls, path: Union[str, Path], device: str = "cpu") -> "SurvivalGANModel":
        """Restore a SurvivalGANModel from a .pt bundle.

        The torch.load call uses weights_only=False because the bundle contains
        XGBoost/sklearn/non-tensor objects. Only load .pt files you trust.
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(path)

        # weights_only=False is required because the bundle contains pickled
        # XGBoost / sklearn objects, not just a state_dict. Trust the source.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            try:
                bundle = torch.load(path, map_location=device, weights_only=False)
            except TypeError:
                # Older torch (< 2.4) — no weights_only kwarg
                bundle = torch.load(path, map_location=device)

        if bundle.get("version") != cls.BUNDLE_VERSION:
            log.warning(
                f"Bundle version {bundle.get('version')} != "
                f"{cls.BUNDLE_VERSION}; loading anyway."
            )

        cfg = SurvivalGANConfig(**bundle["config"])
        model = cls(
            covariates=bundle["covariates"],
            cancer_type_column=bundle["cancer_type_column"],
            time_column=bundle["time_column"],
            status_column=bundle["status_column"],
            cancer_type_label_encoder=bundle.get("cancer_type_label_encoder"),
            column_metadata=bundle.get("column_metadata", {}),
            config=cfg,
            device=device,
        )
        model.cancer_type_classes = bundle["cancer_type_classes"]
        model.training_columns = bundle["training_columns"]

        # Restore full objects
        model.gan = _to_device(bundle["gan"], device)
        model.tte_model = bundle["tte_model"]
        model.censoring_predictor = bundle["censoring_predictor"]

        # The TTE's DeepHit may have CUDA tensors baked in; move to target device.
        # synthcity's DeepHit stores its own .device — we patch it here so
        # downstream .predict() calls use the right device.
        try:
            if hasattr(model.tte_model, "surv_model") and hasattr(model.tte_model.surv_model, "device"):
                model.tte_model.surv_model.device = device
        except Exception as e:  # pragma: no cover — defensive
            log.warning(f"Could not adjust TTE device to {device}: {e}")

        model._fitted = True
        log.info(
            f"Loaded SurvivalGANModel from {path}  | "
            f"covariates={len(model.covariates)} | "
            f"n_cancer_types={len(model.cancer_type_classes)} | "
            f"device={device}"
        )
        return model

    # ------------------------------------------------------------------ #
    #  Introspection helpers                                              #
    # ------------------------------------------------------------------ #

    def list_cancer_types(self) -> List[str]:
        """Return the cancer-type strings the model can generate, if available."""
        if self.cancer_type_label_encoder is not None:
            return list(self.cancer_type_label_encoder.classes_)
        return [str(c) for c in (self.cancer_type_classes or [])]

    def info(self) -> Dict[str, Any]:
        """Lightweight summary of the model — useful for HF endpoint /info routes."""
        return {
            "version": self.BUNDLE_VERSION,
            "covariates": self.covariates,
            "n_covariates": len(self.covariates),
            "cancer_type_column": self.cancer_type_column,
            "available_cancer_types": self.list_cancer_types(),
            "time_column": self.time_column,
            "status_column": self.status_column,
            "fitted": self._fitted,
            "training_columns": self.training_columns,
        }


# =========================================================================== #
#  Helpers for moving the GAN between CPU and GPU                              #
# =========================================================================== #

def _to_cpu(obj):
    """Move a TabularGAN's tensors to CPU before pickling.

    The fitted GAN holds tensors on the training device. For a portable
    bundle we want everything on CPU, so loaders without a GPU still work.
    """
    try:
        if hasattr(obj, "model"):
            obj.model.to("cpu")
            obj.model.device = "cpu"
            if obj.model._original_cond is not None:
                obj.model._original_cond = obj.model._original_cond.cpu()
        if hasattr(obj, "device"):
            obj.device = "cpu"
    except Exception as e:  # pragma: no cover
        log.warning(f"_to_cpu: failed to move object: {e}")
    return obj


def _to_device(obj, device: str):
    """Move a loaded TabularGAN's tensors back onto the target device."""
    try:
        if hasattr(obj, "model"):
            obj.model.to(device)
            obj.model.device = device
            if obj.model._original_cond is not None:
                obj.model._original_cond = obj.model._original_cond.to(device)
        if hasattr(obj, "device"):
            obj.device = device
    except Exception as e:  # pragma: no cover
        log.warning(f"_to_device: failed to move object to {device}: {e}")
    return obj
