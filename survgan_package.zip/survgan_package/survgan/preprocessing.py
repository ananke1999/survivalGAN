"""
MSK-IMPACT 50K → SurvivalGAN preprocessing pipeline.

Refactor of the user's original preprocessing.py — same logic, exposed as a
function with explicit inputs and outputs. The script-style version is gone;
all paths and seeds are arguments.

Public API:
    prepare_data(raw_csv_path, out_dir, ...) -> (df_train, df_test, metadata)

The metadata dict contains:
  - integer_columns:  columns to round-and-cast to int64 after generation
  - cancer_types:     the top-N cancer types kept (others bucketed as "Other")
  - column_metadata:  per-column dtype + bounds for physical-constraint enforcement
  - label_encoders:   sklearn LabelEncoders, keyed by column name (needed at
                      inference to map cancer-type strings back to int codes)

If `out_dir` is provided we also write CSVs and a metadata JSON to disk.
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split


log = logging.getLogger(__name__)


# Columns dropped before encoding — they are either identifiers, derived flags,
# version strings, or have prohibitive cardinality. This list is identical to
# the one in the user's original preprocessing.py.
DROP_ID_COLS = [
    "Patient ID", "Sample ID", "Study ID",
    "Sample Type",                    # used for dedup, not a feature
    "Gene Panel",                     # assay label
    "FACETS Suite Version",           # version string
    "Somatic Status",                 # near-constant
    "Purity Estimate from Mutations", # binary flag, low info
    "HLA Genotype Available",         # derived flag
    "Number of Samples Per Patient",  # dedup artifact
    "Oncotree Code",                  # redundant with Cancer Type
    "Cancer Type Detailed",           # too high cardinality
    "HLA-A Allele 1 Genotype", "HLA-A Allele 2 Genotype",
    "HLA-B Allele 1 Genotype", "HLA-B Allele 2 Genotype",
    "HLA-C Allele 1 Genotype", "HLA-C Allele 2 Genotype",
    "Primary Site",
]

# Columns stored as String in the raw CSV but semantically numeric.
NUMERIC_STRING_COLS = ["Pathologist Estimated Tumor Purity", "Age at Diagnosis"]

INT_CANDIDATES = {
    "Age at Diagnosis", "Mutation Count",
    "Number of Other Cancer Types", "Sample coverage",
}

CLIP_QUANTILE_COLS = ["TMB Score", "Mutation Count", "MSI Score"]

# Known semantic bounds used for physical-constraint enforcement at generation
# time. These override observed bounds where they are stricter.
SEMANTIC_BOUNDS = {
    "Fraction Genome Altered":            (0.0, 1.0),
    "FACETS Estimated Purity":            (0.0, 1.0),
    "Pathologist Estimated Tumor Purity": (0.0, 100.0),
    "Ploidy (FACETS)":                    (0.0, None),
    "MSI Score":                          (0.0, None),
    "TMB Score":                          (0.0, None),
    "Mutation Count":                     (0, None),
    "time":                               (1e-3, None),
    "Age at Diagnosis":                   (0, 120),
}


def _pick_sample(group: pd.DataFrame) -> pd.Series:
    """Patient-level dedup: prefer Primary samples, else first row."""
    primary = group[group["Sample Type"] == "Primary"]
    return primary.iloc[0] if not primary.empty else group.iloc[0]


def _coerce_types(split: pd.DataFrame) -> pd.DataFrame:
    """Coerce string-typed numeric columns to numeric dtype."""
    split = split.copy()
    for col in NUMERIC_STRING_COLS:
        if col in split.columns:
            split[col] = pd.to_numeric(split[col], errors="coerce")
    if "Whole Genome Doubling Status (FACETS)" in split.columns:
        split["Whole Genome Doubling Status (FACETS)"] = (
            split["Whole Genome Doubling Status (FACETS)"]
            .astype(str)
            .replace("nan", np.nan)
        )
    return split


def _col_bounds(df_train: pd.DataFrame, col: str,
                semantic: Optional[Tuple] = None) -> List[float]:
    """Return tighter of (observed min, observed max) and semantic bounds."""
    obs_lo = float(df_train[col].min())
    obs_hi = float(df_train[col].max())
    if semantic is None:
        return [obs_lo, obs_hi]
    sem_lo, sem_hi = semantic
    lo = obs_lo if sem_lo is None else max(obs_lo, sem_lo)
    hi = obs_hi if sem_hi is None else min(obs_hi, sem_hi)
    return [lo, hi]


def prepare_data(
    raw_csv_path: str,
    out_dir: Optional[str] = None,
    top_n_cancer_types: int = 15,
    high_missing_threshold: float = 0.40,
    test_size: float = 0.20,
    random_seed: int = 42,
    time_max: float = 600.0,
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict]:
    """
    Run the full MSK-IMPACT 50K preprocessing pipeline.

    Parameters
    ----------
    raw_csv_path : str
        Path to the raw msk_impact_50K.csv.
    out_dir : Optional[str]
        If set, writes survival_gan_train.csv, survival_gan_test.csv, and
        survival_gan_column_metadata.json into this directory.
    top_n_cancer_types : int
        Cancer types outside the top-N (by count in the train split) are
        bucketed as "Other".
    high_missing_threshold : float
        Drop columns with more than this fraction of missing values in train.
    test_size : float
        Hold-out fraction for the test split (stratified on event indicator).
    random_seed : int
        Seed for the train/test split.
    time_max : float
        Drop rows whose Overall Survival (Months) is >= this. The MSK CSV has
        a handful of records up to ~700 months that are obvious data-entry
        errors; the default 600 keeps real long survivors but excludes those.

    Returns
    -------
    (df_train, df_test, metadata)
        df_train, df_test : preprocessed DataFrames with `time`, `status`, and
                            17 covariates (label-encoded for categoricals).
        metadata : dict containing integer_columns, cancer_types, column_metadata,
                   label_encoders, and source paths.
    """
    np.random.seed(random_seed)

    log.info(f"Loading {raw_csv_path}")
    df = pd.read_csv(raw_csv_path, low_memory=False)
    df.columns = df.columns.str.strip()
    log.info(f"Raw shape: {df.shape}")

    # ── 1. SURVIVAL LABEL CHECKS ────────────────────────────────────────────
    df = df.dropna(subset=["Overall Survival (Months)", "Overall Survival Status"])
    df["status"] = df["Overall Survival Status"].str.startswith("1").astype(int)
    df["time"] = df["Overall Survival (Months)"].astype(float)
    df = df.drop(columns=["Overall Survival (Months)", "Overall Survival Status"])
    df = df[(df["time"] > 0) & (df["time"] < time_max)].reset_index(drop=True)
    log.info(f"After survival filter: {df.shape}")

    # ── 2. PATIENT-LEVEL DE-DUPLICATION ─────────────────────────────────────
    df = df.groupby("Patient ID", group_keys=False).apply(_pick_sample)
    df = df.reset_index(drop=True)
    log.info(f"After patient-level de-duplication: {df.shape}")

    # ── 3. TRAIN/TEST SPLIT (stratified on status) ──────────────────────────
    df_train, df_test = train_test_split(
        df, train_size=1.0 - test_size, random_state=random_seed,
        stratify=df["status"],
    )
    df_train = df_train.reset_index(drop=True)
    df_test = df_test.reset_index(drop=True)
    log.info(f"Train: {df_train.shape}  event rate: {df_train['status'].mean():.1%}")
    log.info(f"Test:  {df_test.shape}  event rate: {df_test['status'].mean():.1%}")

    # ── 4. DROP ID + HIGH-CARDINALITY COLUMNS ───────────────────────────────
    df_train = df_train.drop(columns=DROP_ID_COLS, errors="ignore")
    df_test = df_test.drop(columns=DROP_ID_COLS, errors="ignore")

    # ── 4b. BUCKET RARE CANCER TYPES ─────────────────────────────────────────
    cancer_types: List[str] = []
    if "Cancer Type" in df_train.columns:
        top_types = (
            df_train["Cancer Type"].value_counts().head(top_n_cancer_types).index.tolist()
        )
        cancer_types = top_types + ["Other"]
        df_train["Cancer Type"] = df_train["Cancer Type"].where(
            df_train["Cancer Type"].isin(top_types), "Other"
        )
        df_test["Cancer Type"] = df_test["Cancer Type"].where(
            df_test["Cancer Type"].isin(top_types), "Other"
        )
        n_other_train = (df_train["Cancer Type"] == "Other").sum()
        n_other_test = (df_test["Cancer Type"] == "Other").sum()
        log.info(
            f"Cancer Type: kept top-{top_n_cancer_types}, bucketed "
            f"{n_other_train} train / {n_other_test} test rows as 'Other'"
        )

    # ── 4c. CLIP PATHOLOGIST PURITY TO [0, 100] BEFORE IMPUTATION ───────────
    if "Pathologist Estimated Tumor Purity" in df_train.columns:
        for split in [df_train, df_test]:
            col = "Pathologist Estimated Tumor Purity"
            split[col] = pd.to_numeric(split[col], errors="coerce")
            split[col] = split[col].clip(lower=0.0, upper=100.0)

    # ── 5. TYPE COERCIONS + INTEGER-COLUMN DETECTION ────────────────────────
    df_train = _coerce_types(df_train)
    df_test = _coerce_types(df_test)

    integer_columns: List[str] = []
    for col in df_train.columns:
        if col in ("time", "status") or col not in INT_CANDIDATES:
            continue
        s = pd.to_numeric(df_train[col], errors="coerce").dropna()
        if len(s) > 0 and (s == s.round()).all():
            integer_columns.append(col)
    log.info(f"Integer-valued columns detected: {integer_columns}")

    # ── 5a. DROP COLS WITH TOO-HIGH MISSINGNESS (based on train) ────────────
    nan_props = df_train.isna().mean()
    cols_to_drop = nan_props[nan_props > high_missing_threshold].index.tolist()
    if cols_to_drop:
        log.info(f"Dropping high-missing cols (>{high_missing_threshold:.0%}): {cols_to_drop}")
    df_train = df_train.drop(columns=cols_to_drop, errors="ignore")
    df_test = df_test.drop(columns=cols_to_drop, errors="ignore")

    # ── 5b. IMPUTE NUMERIC, FIT ON TRAIN ONLY ──────────────────────────────
    # Compute nan_cols from train+test union — train alone may miss columns
    # whose NaNs fall entirely in the test split (small samples especially).
    # Fit on train only to avoid leakage; transform on both.
    nan_props_train = df_train.isna().mean()
    nan_props_test  = df_test.isna().mean()
    nan_cols = sorted(set(
        nan_props_train[nan_props_train > 0].index.tolist()
        + nan_props_test[nan_props_test > 0].index.tolist()
    ))
    num_vars = [c for c in nan_cols if df_train[c].dtype.kind in "iuf"]
    if num_vars:
        si_num = SimpleImputer(missing_values=np.nan, strategy="median")
        df_train[num_vars] = si_num.fit_transform(df_train[num_vars])
        df_test[num_vars] = si_num.transform(df_test[num_vars])

    # ── 5c. IMPUTE CATEGORICAL, FIT ON TRAIN ONLY ──────────────────────────
    cat_vars = [c for c in nan_cols if df_train[c].dtype.kind == "O"]
    if cat_vars:
        si_cat = SimpleImputer(missing_values=np.nan, strategy="constant", fill_value="Unknown")
        df_train[cat_vars] = si_cat.fit_transform(df_train[cat_vars])
        df_test[cat_vars] = si_cat.transform(df_test[cat_vars])

    # ── 5d. CLIP RIGHT TAILS ON KNOWN CONTINUOUS COLS (train p99) ──────────
    for col in CLIP_QUANTILE_COLS:
        if col not in df_train.columns:
            continue
        hi = float(df_train[col].quantile(0.99))
        for split in [df_train, df_test]:
            split[col] = split[col].clip(lower=0.0, upper=hi)
        log.info(f"Clipped '{col}' to [0, {hi:.2f}]  (train p99)")

    # ── 5e. RESTORE INTEGER DTYPES AFTER IMPUTATION ────────────────────────
    for col in integer_columns:
        if col not in df_train.columns:
            continue
        s_train = pd.to_numeric(df_train[col], errors="coerce")
        fallback = float(s_train.median()) if s_train.notna().any() else 0.0
        for split in (df_train, df_test):
            s = pd.to_numeric(split[col], errors="coerce")
            if s.isna().any():
                s = s.fillna(fallback)
            split[col] = s.round().astype(np.int64)

    # ── 6. LABEL-ENCODE CATEGORICALS ───────────────────────────────────────
    cat_cols = [
        c for c in df_train.columns
        if c not in ("time", "status") and df_train[c].dtype.kind == "O"
    ]
    label_encoders: Dict[str, LabelEncoder] = {}
    for col in cat_cols:
        for split in (df_train, df_test):
            split[col] = split[col].astype(str)
        le = LabelEncoder()
        le.fit(df_train[col])
        label_encoders[col] = le

        train_classes = set(le.classes_)
        fallback = le.classes_[0]
        for split in (df_train, df_test):
            split[col] = split[col].apply(lambda x: x if x in train_classes else fallback)
            split[col] = le.transform(split[col])
        log.info(f"Label encoded '{col}' → {len(le.classes_)} classes")

    # ── 7. FINAL QC ────────────────────────────────────────────────────────
    for name, split in [("train", df_train), ("test", df_test)]:
        assert split.isnull().sum().sum() == 0, f"{name}: NaNs remaining"
        assert (split["time"] > 0).all(), f"{name}: non-positive times"
        assert split["status"].isin([0, 1]).all(), f"{name}: bad status codes"

    # ── 8. BUILD COLUMN METADATA ───────────────────────────────────────────
    all_int_cols = list(set(
        integer_columns + [
            c for c in df_train.columns
            if pd.api.types.is_integer_dtype(df_train[c]) and c != "status"
        ] + ["status"]
    ))
    column_metadata: Dict[str, Dict] = {}
    for col in df_train.columns:
        is_int = col in all_int_cols
        bounds = _col_bounds(df_train, col, semantic=SEMANTIC_BOUNDS.get(col))
        column_metadata[col] = {
            "dtype": "int" if is_int else "float",
            "bounds": bounds,
        }

    metadata = {
        "integer_columns": all_int_cols,
        "cancer_types": cancer_types,
        "column_metadata": column_metadata,
        "label_encoders": label_encoders,
        "time_column": "time",
        "status_column": "status",
        "n_train": len(df_train),
        "n_test": len(df_test),
    }

    # ── 9. WRITE TO DISK (optional) ────────────────────────────────────────
    if out_dir is not None:
        out_path = Path(out_dir)
        out_path.mkdir(parents=True, exist_ok=True)
        train_csv = out_path / "survival_gan_train.csv"
        test_csv = out_path / "survival_gan_test.csv"
        meta_json = out_path / "survival_gan_column_metadata.json"

        df_train.to_csv(train_csv, index=False)
        df_test.to_csv(test_csv, index=False)

        # JSON-safe metadata (drop label_encoders — pickled separately if needed)
        meta_json_safe = {
            "source_train_csv": str(train_csv),
            "source_test_csv":  str(test_csv),
            "time_column":      "time",
            "status_column":    "status",
            "integer_columns":  all_int_cols,
            "cancer_types":     cancer_types,
            "columns":          column_metadata,
        }
        with open(meta_json, "w") as f:
            json.dump(meta_json_safe, f, indent=2)

        log.info(f"Wrote train CSV  → {train_csv}")
        log.info(f"Wrote test CSV   → {test_csv}")
        log.info(f"Wrote metadata   → {meta_json}")
        metadata["source_train_csv"] = str(train_csv)
        metadata["source_test_csv"]  = str(test_csv)

    log.info(
        f"Final columns ({len(df_train.columns)}): {df_train.columns.tolist()}"
    )
    return df_train, df_test, metadata
