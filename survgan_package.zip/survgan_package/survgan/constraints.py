"""
Post-generation sanity passes:

  1. match_real_precision    — snap synthetic numeric values to match the
                               unique-values / decimal-places of the real data
                               (e.g. "Mutation Count" only has integer values,
                               TMB Score has 2 dp, etc.)
  2. enforce_physical_constraints — clip to bounds and cast integer columns

Both are lifted unchanged from the user's original train_survGAN_aws.py.
"""

import logging
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd


log = logging.getLogger(__name__)


DEFAULT_CONSTRAINT_MAP: Dict[str, Dict[str, Any]] = {
    "Age at Diagnosis":                   {"dtype": "int",   "bounds": (0, 120)},
    "Mutation Count":                     {"dtype": "int",   "bounds": (0, None)},
    "Number of Other Cancer Types":       {"dtype": "int",   "bounds": (0, None)},
    "Sample coverage":                    {"dtype": "int",   "bounds": (0, None)},
    "Fraction Genome Altered":            {"dtype": "float", "bounds": (0.0, 1.0)},
    "FACETS Estimated Purity":            {"dtype": "float", "bounds": (0.0, 1.0)},
    "Pathologist Estimated Tumor Purity": {"dtype": "float", "bounds": (0.0, 100.0)},
    "Ploidy (FACETS)":                    {"dtype": "float", "bounds": (0.0, None)},
    "MSI Score":                          {"dtype": "float", "bounds": (0.0, None)},
    "TMB Score":                          {"dtype": "float", "bounds": (0.0, None)},
    "time":                               {"dtype": "float", "bounds": (1e-3, None)},
    "status":                             {"dtype": "int",   "bounds": (0, 1)},
}


def match_real_precision(real_df: pd.DataFrame,
                         syn_df: pd.DataFrame,
                         unique_threshold: int = 1000,
                         skip_cols: Optional[set] = None
                         ) -> Tuple[pd.DataFrame, dict]:
    """Snap synthetic numeric columns to match the precision of real."""
    skip_cols = skip_cols or set()
    out = syn_df.copy()
    report: dict = {}

    for col in syn_df.columns:
        if col in skip_cols or col not in real_df.columns:
            continue
        if not np.issubdtype(real_df[col].dtype, np.number):
            continue
        if not np.issubdtype(syn_df[col].dtype, np.number):
            continue

        real_vals = real_df[col].dropna()
        if len(real_vals) == 0:
            continue

        syn_arr = syn_df[col].to_numpy(dtype=float).copy()
        nan_mask = np.isnan(syn_arr)
        n_uniq_real = int(real_vals.nunique())

        if n_uniq_real <= unique_threshold:
            real_sorted = np.sort(real_vals.unique().astype(float))
            idx = np.searchsorted(real_sorted, syn_arr, side="left")
            idx_clip = np.clip(idx, 1, len(real_sorted) - 1)
            left = real_sorted[idx_clip - 1]
            right = real_sorted[idx_clip]
            snapped = np.where(
                np.abs(syn_arr - left) <= np.abs(syn_arr - right),
                left, right,
            )
            snapped[nan_mask] = np.nan
            out[col] = snapped
            method = f"snap→{n_uniq_real}_vals"
        else:
            sample = real_vals.astype(str).head(2000)
            max_dec = 0
            for v in sample:
                if "." in v:
                    dec_part = v.split(".")[1].rstrip("0")
                    if len(dec_part) > max_dec:
                        max_dec = len(dec_part)
            if max_dec > 0:
                out[col] = np.round(syn_arr, max_dec)
            method = f"round→{max_dec}dp"

        if np.issubdtype(real_df[col].dtype, np.integer) and not nan_mask.any():
            try:
                out[col] = out[col].astype(real_df[col].dtype)
                method += ",int"
            except (ValueError, TypeError):
                pass

        report[col] = {
            "real_nuniq": n_uniq_real,
            "syn_nuniq_before": int(pd.Series(syn_df[col]).nunique()),
            "syn_nuniq_after":  int(pd.Series(out[col]).nunique()),
            "method": method,
        }

    return out, report


def build_constraint_map(real_df: pd.DataFrame,
                         column_metadata: Optional[Dict] = None
                         ) -> Dict[str, Dict[str, Any]]:
    """Build a column → constraint mapping by combining (in priority order):
       1. column_metadata (if provided)
       2. DEFAULT_CONSTRAINT_MAP
       3. inferred from real data (integer if all-integer-valued, observed bounds)
    """
    constraints: Dict[str, Dict[str, Any]] = {}
    json_entries = (column_metadata or {})

    for col in real_df.columns:
        if col in json_entries:
            e = json_entries[col]
            constraints[col] = {
                "dtype":  e.get("dtype", "float"),
                "bounds": tuple(e.get("bounds", (None, None))),
                "source": "metadata",
            }
            continue

        if col in DEFAULT_CONSTRAINT_MAP:
            e = DEFAULT_CONSTRAINT_MAP[col]
            constraints[col] = {
                "dtype":  e["dtype"],
                "bounds": e["bounds"],
                "source": "default_map",
            }
            continue

        if np.issubdtype(real_df[col].dtype, np.number):
            real_vals = pd.to_numeric(real_df[col], errors="coerce").dropna()
            if len(real_vals) == 0:
                continue
            is_int = (real_vals == real_vals.round()).all()
            constraints[col] = {
                "dtype":  "int" if is_int else "float",
                "bounds": (float(real_vals.min()), float(real_vals.max())),
                "source": "inferred",
            }

    return constraints


def enforce_physical_constraints(real_df: pd.DataFrame,
                                 syn_df: pd.DataFrame,
                                 constraints: Dict[str, Dict[str, Any]]
                                 ) -> Tuple[pd.DataFrame, Dict[str, Dict]]:
    """Apply dtype + bounds constraints to each synthetic column."""
    out = syn_df.copy()
    report: Dict[str, Dict] = {}

    for col, spec in constraints.items():
        if col not in out.columns:
            continue
        if not np.issubdtype(out[col].dtype, np.number):
            continue

        arr = out[col].to_numpy(dtype=float).copy()
        n = len(arr)
        lo, hi = spec["bounds"]
        dtype = spec["dtype"]

        n_below = int((arr < lo).sum()) if lo is not None else 0
        n_above = int((arr > hi).sum()) if hi is not None else 0

        if lo is not None:
            arr = np.where(arr < lo, lo, arr)
        if hi is not None:
            arr = np.where(arr > hi, hi, arr)

        n_nonint = 0
        if dtype == "int":
            rounded = np.round(arr)
            n_nonint = int((arr != rounded).sum())
            arr = rounded
            try:
                out[col] = arr.astype(np.int64)
            except (ValueError, TypeError):
                out[col] = arr
        else:
            out[col] = arr

        report[col] = {
            "dtype":       dtype,
            "bounds":      (lo, hi),
            "n_below":     n_below,
            "n_above":     n_above,
            "n_rounded":   n_nonint,
            "pct_modified": 100.0 * (n_below + n_above + n_nonint) / max(n, 1),
            "source":      spec.get("source", "?"),
        }

    return out, report
