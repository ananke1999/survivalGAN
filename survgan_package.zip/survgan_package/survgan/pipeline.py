"""
Core GAN building blocks for SurvivalGAN.

This module is a refactor of the user's original survGAN.py — it contains
ONLY the architecture classes (encoders, MLP, GAN, TabularGAN), with the
original SurvivalPipeline and main() removed. The high-level orchestration
now lives in model.SurvivalGANModel, which adds:

  - Cancer-type conditioning (instead of the paper's full survival conditional)
  - .pt save/load via torch.save
  - Subset-of-covariates training

The classes here are unchanged from the user's working code so we don't
regress any of the bug fixes already in survGAN.py (integer dtype handling,
log-time clamping, etc.).
"""

import logging
from typing import Any, Callable, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader as TorchDataLoader, TensorDataset, Sampler
from sklearn.mixture import BayesianGaussianMixture
from sklearn.preprocessing import OneHotEncoder as SklearnOneHotEncoder
from tqdm import tqdm


log = logging.getLogger(__name__)


# =========================================================================== #
#  ACTIVATIONS                                                                 #
# =========================================================================== #

class GumbelSoftmax(nn.Module):
    """Gumbel-Softmax for differentiable discrete sampling."""

    def __init__(self, tau: float = 0.2, hard: bool = False, dim: int = -1):
        super().__init__()
        self.tau, self.hard, self.dim = tau, hard, dim

    def forward(self, logits: torch.Tensor) -> torch.Tensor:
        return nn.functional.gumbel_softmax(
            logits, tau=self.tau, hard=self.hard, dim=self.dim,
        )


ACTIVATIONS = {
    "none":        lambda: nn.Identity(),
    "elu":         lambda: nn.ELU(),
    "relu":        lambda: nn.ReLU(),
    "leaky_relu":  lambda: nn.LeakyReLU(),
    "selu":        lambda: nn.SELU(),
    "tanh":        lambda: nn.Tanh(),
    "sigmoid":     lambda: nn.Sigmoid(),
    "softmax":     lambda: GumbelSoftmax(),
    "gelu":        lambda: nn.GELU(),
    "silu":        lambda: nn.SiLU(),
    "prelu":       lambda: nn.PReLU(),
    "relu6":       lambda: nn.ReLU6(),
    "softplus":    lambda: nn.Softplus(),
    "hardtanh":    lambda: nn.Hardtanh(),
}


def get_nonlin(name: str) -> nn.Module:
    key = name.lower().replace("_", "")
    aliases = {"leakyrelu": "leaky_relu", "swish": "silu"}
    key = aliases.get(key, key)
    for k in (name, key, name.lower().replace("_", "")):
        if k in ACTIVATIONS:
            return ACTIVATIONS[k]()
    raise ValueError(f"Unknown activation: {name}")


# =========================================================================== #
#  MULTI-ACTIVATION HEAD                                                       #
# =========================================================================== #

class MultiActivationHead(nn.Module):
    """Applies different activations to different output slices.
    Tabular-data trick: continuous slices use identity/tanh, discrete slices use softmax."""

    def __init__(self, activations: List[Tuple[nn.Module, int]], device: Any = "cpu"):
        super().__init__()
        self.activations = nn.ModuleList()
        self.lengths: List[int] = []
        self.device = device
        for act, length in activations:
            self.activations.append(act)
            self.lengths.append(length)

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        out = torch.zeros_like(X)
        idx = 0
        for act, length in zip(self.activations, self.lengths):
            out[..., idx:idx + length] = act(X[..., idx:idx + length])
            idx += length
        return out


# =========================================================================== #
#  MLP (Generator / Discriminator backbone)                                    #
# =========================================================================== #

class LinearLayer(nn.Module):
    """Single hidden layer: [Dropout?] → Linear → [BatchNorm?] → Activation."""

    def __init__(
        self,
        n_units_in: int,
        n_units_out: int,
        dropout: float = 0.0,
        batch_norm: bool = False,
        nonlin: Optional[str] = "relu",
        device: Any = "cpu",
    ):
        super().__init__()
        self.device = device
        layers: list = []
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        layers.append(nn.Linear(n_units_in, n_units_out))
        if batch_norm:
            layers.append(nn.BatchNorm1d(n_units_out))
        if nonlin is not None:
            layers.append(get_nonlin(nonlin))
        self.model = nn.Sequential(*layers).to(device)

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        return self.model(X.float())


class ResidualLinearLayer(nn.Module):
    """LinearLayer wrapped with a concatenation-style skip connection.
    Output dim = n_units_out + n_units_in."""

    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__()
        device = kwargs.get("device", "cpu")
        self.inner = LinearLayer(*args, **kwargs)
        self.device = device

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        if X.shape[-1] == 0:
            out_feats = None
            for m in self.inner.model:
                if isinstance(m, nn.Linear):
                    out_feats = m.out_features
                    break
            return torch.zeros((*X.shape[:-1], out_feats or 0), device=self.device)
        out = self.inner(X)
        return torch.cat([out, X], dim=-1)


class MLP(nn.Module):
    """Generator / Discriminator backbone.
    Concatenation-style residual connections optional. See LinearLayer for layer detail."""

    def __init__(
        self,
        n_units_in: int,
        n_units_out: int,
        *,
        n_layers_hidden: int = 2,
        n_units_hidden: int = 256,
        nonlin: str = "relu",
        nonlin_out: Optional[List[Tuple[str, int]]] = None,
        batch_norm: bool = False,
        dropout: float = 0.0,
        residual: bool = False,
        lr: float = 1e-3,
        weight_decay: float = 1e-3,
        opt_betas: tuple = (0.9, 0.999),
        device: Any = "cpu",
        random_state: int = 0,
        task_type: str = "regression",  # kept for API compat
    ):
        super().__init__()
        self.device = device

        Block = ResidualLinearLayer if residual else LinearLayer

        layers: List[nn.Module] = []
        cur_in = n_units_in

        if n_layers_hidden > 0:
            layers.append(Block(
                cur_in, n_units_hidden,
                batch_norm=batch_norm, nonlin=nonlin, device=device,
            ))
            cur_in = n_units_hidden + (cur_in if residual else 0)

            for _ in range(n_layers_hidden - 1):
                layers.append(Block(
                    cur_in, n_units_hidden,
                    batch_norm=batch_norm, nonlin=nonlin,
                    dropout=dropout, device=device,
                ))
                cur_in = n_units_hidden + (cur_in if residual else 0)

            layers.append(nn.Linear(cur_in, n_units_out, device=device))
        else:
            layers.append(nn.Linear(n_units_in, n_units_out, device=device))

        if nonlin_out is not None:
            acts = [(get_nonlin(name), length) for name, length in nonlin_out]
            layers.append(MultiActivationHead(acts, device=device))

        self.model = nn.Sequential(*layers).to(device)

        self.optimizer = torch.optim.Adam(
            self.parameters(), lr=lr, weight_decay=weight_decay, betas=opt_betas,
        )

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        return self.model(X.float())


# =========================================================================== #
#  GAN training loop (Wasserstein + GP + identifiability penalty)              #
# =========================================================================== #

class GAN(nn.Module):
    """Wasserstein GAN with gradient penalty + optional identifiability penalty."""

    def __init__(
        self,
        n_features: int,
        n_units_latent: int,
        n_units_conditional: int = 0,
        # generator
        generator_n_layers_hidden: int = 2,
        generator_n_units_hidden: int = 250,
        generator_nonlin: str = "leaky_relu",
        generator_nonlin_out: Optional[List[Tuple[str, int]]] = None,
        generator_n_iter: int = 2000,
        generator_batch_norm: bool = False,
        generator_dropout: float = 0.0,
        generator_lr: float = 2e-4,
        generator_weight_decay: float = 1e-3,
        generator_residual: bool = True,
        generator_opt_betas: tuple = (0.9, 0.999),
        generator_extra_penalties: Optional[list] = None,
        generator_extra_penalty_cbks: Optional[List[Callable]] = None,
        # discriminator
        discriminator_n_layers_hidden: int = 3,
        discriminator_n_units_hidden: int = 300,
        discriminator_nonlin: str = "leaky_relu",
        discriminator_n_iter: int = 1,
        discriminator_batch_norm: bool = False,
        discriminator_dropout: float = 0.1,
        discriminator_lr: float = 2e-4,
        discriminator_weight_decay: float = 1e-3,
        discriminator_opt_betas: tuple = (0.9, 0.999),
        # training
        batch_size: int = 64,
        random_state: int = 0,
        clipping_value: int = 0,
        lambda_gradient_penalty: float = 10.0,
        lambda_identifiability_penalty: float = 0.1,
        dataloader_sampler: Optional[Sampler] = None,
        device: Any = "cpu",
        # not used but kept for API compat
        n_iter_min: int = 100,
        n_iter_print: int = 50,
        patience: int = 20,
        patience_metric: Any = None,
        **kwargs: Any,
    ):
        super().__init__()
        if generator_extra_penalties is None:
            generator_extra_penalties = []
        if generator_extra_penalty_cbks is None:
            generator_extra_penalty_cbks = []

        self.device = device
        self.n_features = n_features
        self.n_units_latent = n_units_latent
        self.n_units_conditional = n_units_conditional
        self.generator_extra_penalties = generator_extra_penalties
        self.generator_extra_penalty_cbks = generator_extra_penalty_cbks

        self.generator = MLP(
            n_units_in=n_units_latent + n_units_conditional,
            n_units_out=n_features,
            n_layers_hidden=generator_n_layers_hidden,
            n_units_hidden=generator_n_units_hidden,
            nonlin=generator_nonlin,
            nonlin_out=generator_nonlin_out,
            batch_norm=generator_batch_norm,
            dropout=generator_dropout,
            residual=generator_residual,
            lr=generator_lr,
            weight_decay=generator_weight_decay,
            opt_betas=generator_opt_betas,
            device=device,
        ).to(device)

        self.discriminator = MLP(
            n_units_in=n_features + n_units_conditional,
            n_units_out=1,
            n_layers_hidden=discriminator_n_layers_hidden,
            n_units_hidden=discriminator_n_units_hidden,
            nonlin=discriminator_nonlin,
            nonlin_out=[("none", 1)],
            batch_norm=discriminator_batch_norm,
            dropout=discriminator_dropout,
            residual=False,
            lr=discriminator_lr,
            weight_decay=discriminator_weight_decay,
            opt_betas=discriminator_opt_betas,
            device=device,
        ).to(device)

        self.generator_n_iter = generator_n_iter
        self.discriminator_n_iter = discriminator_n_iter
        self.n_iter_print = n_iter_print
        self.n_iter_min = n_iter_min
        self.patience = patience
        self.patience_metric = patience_metric
        self.batch_size = batch_size
        self.clipping_value = clipping_value
        self.lambda_gradient_penalty = lambda_gradient_penalty
        self.lambda_identifiability_penalty = lambda_identifiability_penalty
        self.random_state = random_state
        self.dataloader_sampler = dataloader_sampler

        self._original_cond: Optional[torch.Tensor] = None

    # -------------------- Public API --------------------

    def fit(
        self,
        X: np.ndarray,
        cond: Optional[np.ndarray] = None,
        **kwargs: Any,
    ) -> "GAN":
        Xt = self._to_tensor(X).float()
        condt = self._to_tensor(cond).float() if cond is not None else None

        if self.n_units_conditional > 0:
            if condt is None:
                raise ValueError("Expecting conditional for training")
            if condt.shape[1] != self.n_units_conditional:
                raise ValueError(
                    f"Conditional dim mismatch: expected {self.n_units_conditional}, got {condt.shape[1]}"
                )

        self._train(Xt, condt)
        return self

    def generate(self, count: int, cond: Optional[np.ndarray] = None) -> np.ndarray:
        self.generator.eval()
        condt = self._to_tensor(cond).float() if cond is not None else None
        with torch.no_grad():
            return self._forward(count, condt).detach().cpu().numpy()

    def _forward(
        self, count: int, cond: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if cond is None and self.n_units_conditional > 0:
            if self._original_cond is None:
                raise ValueError("No original conditional stored.")
            idxs = torch.randint(len(self._original_cond), (count,))
            cond = self._original_cond[idxs]
        if cond is not None and len(cond.shape) == 1:
            cond = cond.reshape(-1, 1)

        noise = torch.randn(count, self.n_units_latent, device=self.device)
        noise = self._cat_cond(noise, cond)
        return self.generator(noise)

    # -------------------- Training loop --------------------

    def _train(self, X: torch.Tensor, cond: Optional[torch.Tensor] = None) -> None:
        self._original_cond = cond

        X_train, X_val, cond_train, cond_val = self._train_test_split(X, cond)

        if cond_train is None:
            dataset = TensorDataset(X_train)
        else:
            dataset = TensorDataset(X_train, cond_train)

        loader = TorchDataLoader(
            dataset, batch_size=self.batch_size,
            sampler=self.dataloader_sampler, pin_memory=False,
        )

        for i in tqdm(range(self.generator_n_iter), desc="GAN training"):
            g_loss, d_loss = self._train_epoch(loader)

            if (i + 1) % self.n_iter_print == 0:
                log.debug(
                    f"[{i}/{self.generator_n_iter}] D_loss={d_loss:.4f}  G_loss={g_loss:.4f}"
                )

    def _train_epoch(self, loader: TorchDataLoader) -> Tuple[float, float]:
        G_losses, D_losses = [], []
        for data in loader:
            cond = data[1] if self.n_units_conditional > 0 else None
            X = data[0]

            D_losses.append(self._step_discriminator(X, cond))
            G_losses.append(self._step_generator(X, cond))

        return float(np.mean(G_losses)), float(np.mean(D_losses))

    def _step_generator(self, X: torch.Tensor, cond: Optional[torch.Tensor]) -> float:
        self.generator.train()
        self.generator.optimizer.zero_grad()

        real_X_raw = X.to(self.device)
        real_X = self._cat_cond(real_X_raw, cond)
        bs = len(real_X)

        noise = torch.randn(bs, self.n_units_latent, device=self.device)
        noise = self._cat_cond(noise, cond)
        fake_raw = self.generator(noise)
        fake = self._cat_cond(fake_raw, cond)

        output = self.discriminator(fake).squeeze().float()
        errG = -torch.mean(output)

        for cb in self.generator_extra_penalty_cbks:
            errG += cb(real_X_raw, fake_raw, cond=cond)

        if "identifiability_penalty" in self.generator_extra_penalties:
            errG += self._loss_identifiability(real_X, fake)

        errG.backward()
        if self.clipping_value > 0:
            nn.utils.clip_grad_norm_(self.generator.parameters(), self.clipping_value)
        self.generator.optimizer.step()

        if torch.isnan(errG):
            raise RuntimeError("NaN in generator loss")
        return errG.item()

    def _step_discriminator(self, X: torch.Tensor, cond: Optional[torch.Tensor]) -> float:
        self.discriminator.train()
        bs = min(self.batch_size, len(X))
        errors = []

        for _ in range(self.discriminator_n_iter):
            real_X = self._cat_cond(X.to(self.device), cond)
            real_output = self.discriminator(real_X).squeeze().float()

            noise = torch.randn(bs, self.n_units_latent, device=self.device)
            noise = self._cat_cond(noise, cond)
            fake_raw = self.generator(noise)
            fake = self._cat_cond(fake_raw, cond)
            fake_output = self.discriminator(fake.detach()).squeeze()

            errD = -torch.mean(real_output) + torch.mean(fake_output)
            gp = self._loss_gradient_penalty(real_X, fake, bs)

            self.discriminator.optimizer.zero_grad()
            gp.backward(retain_graph=True)
            errD.backward()
            if self.clipping_value > 0:
                nn.utils.clip_grad_norm_(self.discriminator.parameters(), self.clipping_value)
            self.discriminator.optimizer.step()

            errors.append(errD.item())

        if np.isnan(np.mean(errors)):
            raise RuntimeError("NaN in discriminator loss")
        return float(np.mean(errors))

    # -------------------- Losses --------------------

    def _loss_gradient_penalty(
        self, real: torch.Tensor, fake: torch.Tensor, bs: int,
    ) -> torch.Tensor:
        alpha = torch.rand(bs, 1, device=self.device)
        interp = (alpha * real + (1 - alpha) * fake).requires_grad_(True)
        d_interp = self.discriminator(interp).squeeze(-1)
        labels = torch.ones(len(interp), device=self.device)
        grads = torch.autograd.grad(
            d_interp, interp, grad_outputs=labels,
            create_graph=True, retain_graph=True, only_inputs=True, allow_unused=True,
        )[0]
        grads = grads.view(grads.size(0), -1)
        penalty = ((grads.norm(2, dim=-1) - 1) ** 2).mean()
        return self.lambda_gradient_penalty * penalty

    def _loss_identifiability(
        self, real: torch.Tensor, fake: torch.Tensor,
    ) -> torch.Tensor:
        return (
            -self.lambda_identifiability_penalty
            * (real - fake).square().sum(dim=-1).sqrt().mean()
        )

    # -------------------- Helpers --------------------

    def _cat_cond(self, X: torch.Tensor, cond: Optional[torch.Tensor]) -> torch.Tensor:
        if cond is None or self.n_units_conditional == 0:
            return X
        return torch.cat([X, cond.to(self.device)], dim=-1)

    def _to_tensor(self, X: Any) -> torch.Tensor:
        if isinstance(X, torch.Tensor):
            return X.to(self.device)
        return torch.from_numpy(np.asarray(X)).to(self.device)

    def _train_test_split(
        self, X: torch.Tensor, cond: Optional[torch.Tensor],
    ) -> Tuple[torch.Tensor, torch.Tensor, Optional[torch.Tensor], Optional[torch.Tensor]]:
        """80/20 split only when patience_metric is set; otherwise use all data
        for training. Faithful to the original survGAN.py behavior — splitting
        unconditionally would silently throw away 20% of training samples."""
        if self.patience_metric is None:
            return X, None, cond, None

        n = len(X)
        idx = np.arange(n)
        np.random.shuffle(idx)
        split = int(n * 0.8)
        train_idx, val_idx = idx[:split], idx[split:]
        return X[train_idx], X[val_idx], (cond[train_idx] if cond is not None else None), (cond[val_idx] if cond is not None else None)


# =========================================================================== #
#  TABULAR ENCODERS                                                            #
# =========================================================================== #

def _find_discrete_columns(df: pd.DataFrame, limit: int = 20) -> List[str]:
    """Columns with ≤ `limit` unique values are treated as discrete."""
    return [c for c in df.columns if df[c].nunique() <= limit]


class BayesianGMMFeatureEncoder:
    """Encodes a single continuous feature using BayesianGMM (CTGAN-style).
    Output per sample: [normalized_value, p(comp_0), p(comp_1), ...]"""

    def __init__(self, n_components: int = 10):
        self.n_components = n_components

    def fit(self, feature: pd.Series) -> "BayesianGMMFeatureEncoder":
        self.feature_name_in = feature.name
        vals = feature.values.astype(float).reshape(-1, 1)

        self.bgm = BayesianGaussianMixture(
            n_components=self.n_components,
            weight_concentration_prior=0.001,
            max_iter=300,
            n_init=1,
            random_state=0,
        )
        self.bgm.fit(vals)

        self.means = self.bgm.means_.flatten()
        self.stds = np.sqrt(self.bgm.covariances_.flatten())
        self.stds = np.clip(self.stds, 1e-6, None)

        self.n_features_out = 1 + self.n_components
        self.feature_names_out = [f"{self.feature_name_in}.norm"] + [
            f"{self.feature_name_in}.comp_{i}" for i in range(self.n_components)
        ]
        self.feature_types_out = ["continuous"] + ["discrete"] * self.n_components
        return self

    def transform(self, feature: pd.Series) -> pd.DataFrame:
        vals = feature.values.astype(float).reshape(-1, 1)
        probs = self.bgm.predict_proba(vals)
        comps = probs.argmax(axis=1)

        mu = self.means[comps]
        sigma = self.stds[comps]
        normed = (vals.flatten() - mu) / (4 * sigma)
        normed = np.clip(normed, -0.99, 0.99)
        normed = (normed + 1) / 2

        onehot = np.zeros((len(vals), self.n_components))
        onehot[np.arange(len(vals)), comps] = 1.0

        out = np.column_stack([normed, onehot])
        return pd.DataFrame(out, columns=self.feature_names_out, index=feature.index)

    def inverse_transform(self, data: pd.DataFrame) -> pd.Series:
        normed = data.iloc[:, 0].values
        comp_probs = data.iloc[:, 1:].values
        comps = comp_probs.argmax(axis=1)

        v = normed * 2 - 1
        mu = self.means[comps]
        sigma = self.stds[comps]
        vals = v * (4 * sigma) + mu
        return pd.Series(vals, name=self.feature_name_in, index=data.index)


class OneHotFeatureEncoder:
    """Encodes a single discrete feature using OneHot."""

    def fit(self, feature: pd.Series) -> "OneHotFeatureEncoder":
        self.feature_name_in = feature.name
        self.enc = SklearnOneHotEncoder(handle_unknown="ignore", sparse_output=False)
        self.enc.fit(feature.values.reshape(-1, 1))

        cats = self.enc.categories_[0]
        self.n_features_out = len(cats)
        self.feature_names_out = [f"{self.feature_name_in}.{c}" for c in cats]
        self.feature_types_out = ["discrete"] * self.n_features_out
        return self

    def transform(self, feature: pd.Series) -> pd.DataFrame:
        out = self.enc.transform(feature.values.reshape(-1, 1))
        return pd.DataFrame(out, columns=self.feature_names_out, index=feature.index)

    def inverse_transform(self, data: pd.DataFrame) -> pd.Series:
        inv = self.enc.inverse_transform(data.values)
        return pd.Series(inv.flatten(), name=self.feature_name_in, index=data.index)


class _FeatureInfo:
    def __init__(self, name, feature_type, transform, output_dimensions,
                 transformed_features, trans_feature_types):
        self.name = name
        self.feature_type = feature_type
        self.transform = transform
        self.output_dimensions = output_dimensions
        self.transformed_features = transformed_features
        self.trans_feature_types = trans_feature_types


class TabularEncoder:
    """Encodes a DataFrame with mixed continuous/discrete columns."""

    def __init__(self, max_clusters: int = 10, categorical_limit: int = 10):
        self.max_clusters = max_clusters
        self.categorical_limit = categorical_limit

    def fit(self, df: pd.DataFrame) -> "TabularEncoder":
        disc_cols = _find_discrete_columns(df, self.categorical_limit)
        self._column_raw_dtypes = df.dtypes
        self._info_list: List[_FeatureInfo] = []
        self.output_dimensions = 0

        for col in df.columns:
            ftype = "discrete" if col in disc_cols else "continuous"
            if ftype == "discrete":
                enc = OneHotFeatureEncoder().fit(df[col])
            else:
                enc = BayesianGMMFeatureEncoder(n_components=self.max_clusters).fit(df[col])

            info = _FeatureInfo(
                name=col, feature_type=ftype, transform=enc,
                output_dimensions=enc.n_features_out,
                transformed_features=enc.feature_names_out,
                trans_feature_types=enc.feature_types_out,
            )
            self._info_list.append(info)
            self.output_dimensions += info.output_dimensions

        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        parts = []
        for info in self._info_list:
            parts.append(info.transform.transform(df[info.name]))
        result = pd.concat(parts, axis=1)
        result.index = df.index
        return result

    def inverse_transform(self, data: pd.DataFrame) -> pd.DataFrame:
        recovered = []
        names = []
        st = 0
        for info in self._info_list:
            dim = info.output_dimensions
            chunk = data.iloc[:, st:st + dim]
            recovered.append(info.transform.inverse_transform(chunk).values)
            names.append(info.name)
            st += dim

        out = pd.DataFrame(np.column_stack(recovered), columns=names, index=data.index)
        # Restore original dtypes; ROUND before casting to integer to avoid
        # truncation (e.g. GMM-generated 2.6 should become 3, not 2).
        for col in out.columns:
            if col in self._column_raw_dtypes.index:
                tgt = self._column_raw_dtypes[col]
                try:
                    if np.issubdtype(tgt, np.integer):
                        out[col] = out[col].round().astype(tgt)
                    else:
                        out[col] = out[col].astype(tgt)
                except (ValueError, TypeError):
                    pass
        return out

    def layout(self) -> List[_FeatureInfo]:
        return self._info_list

    def n_features(self) -> int:
        return sum(info.output_dimensions for info in self._info_list)

    def activation_layout(
        self, discrete_activation: str, continuous_activation: str,
    ) -> List[Tuple[str, int]]:
        out = []
        acts = {"discrete": discrete_activation, "continuous": continuous_activation}
        for info in self._info_list:
            ct = info.trans_feature_types[0]
            d = 0
            for t in info.trans_feature_types:
                if t != ct:
                    out.append((acts[ct], d))
                    ct = t
                    d = 0
                d += 1
            out.append((acts[ct], d))
        return out


# =========================================================================== #
#  TABULAR GAN (TabularEncoder + GAN)                                          #
# =========================================================================== #

class TabularGAN(nn.Module):
    """GAN for tabular data: encodes → trains GAN → decodes."""

    def __init__(
        self,
        X: pd.DataFrame,
        n_units_latent: int,
        cond: Optional[Union[pd.DataFrame, pd.Series, np.ndarray]] = None,
        encoder_max_clusters: int = 5,
        dataloader_sampler: Optional[Sampler] = None,
        device: Any = "cpu",
        # generator
        generator_n_layers_hidden: int = 2,
        generator_n_units_hidden: int = 150,
        generator_nonlin: str = "leaky_relu",
        generator_nonlin_out_discrete: str = "softmax",
        generator_nonlin_out_continuous: str = "none",
        generator_n_iter: int = 2000,
        generator_batch_norm: bool = False,
        generator_dropout: float = 0.0,
        generator_lr: float = 1e-3,
        generator_weight_decay: float = 1e-3,
        generator_residual: bool = True,
        generator_opt_betas: tuple = (0.9, 0.999),
        generator_extra_penalties: Optional[list] = None,
        # discriminator
        discriminator_n_layers_hidden: int = 3,
        discriminator_n_units_hidden: int = 300,
        discriminator_nonlin: str = "leaky_relu",
        discriminator_n_iter: int = 1,
        discriminator_batch_norm: bool = False,
        discriminator_dropout: float = 0.1,
        discriminator_lr: float = 1e-3,
        discriminator_weight_decay: float = 1e-3,
        discriminator_opt_betas: tuple = (0.9, 0.999),
        # training
        batch_size: int = 64,
        random_state: int = 0,
        clipping_value: int = 0,
        lambda_gradient_penalty: float = 10.0,
        lambda_identifiability_penalty: float = 0.1,
        n_iter_print: int = 50,
        n_iter_min: int = 100,
        patience: int = 10,
        **kwargs: Any,
    ):
        super().__init__()
        if generator_extra_penalties is None:
            generator_extra_penalties = []

        self.columns = X.columns
        self.device = device

        self.encoder = TabularEncoder(
            max_clusters=encoder_max_clusters,
            categorical_limit=10,
        ).fit(X)

        self.cond_encoder: Optional[SklearnOneHotEncoder] = None
        n_units_conditional = 0
        self.predefined_conditional = cond is not None

        if cond is not None:
            cond = np.asarray(cond)
            if len(cond.shape) == 1:
                cond = cond.reshape(-1, 1)
            self.cond_encoder = SklearnOneHotEncoder(
                handle_unknown="ignore", sparse_output=False,
            ).fit(cond)
            n_units_conditional = self.cond_encoder.transform(cond).shape[-1]

        # The conditional-loss callback is a bound METHOD on this class
        # (self._cond_loss), not a closure inside __init__. Closures defined
        # inside methods aren't picklable, which would break torch.save()
        # of the model bundle.
        self.model = GAN(
            n_features=self.encoder.n_features(),
            n_units_latent=n_units_latent,
            n_units_conditional=n_units_conditional,
            batch_size=batch_size,
            generator_n_layers_hidden=generator_n_layers_hidden,
            generator_n_units_hidden=generator_n_units_hidden,
            generator_nonlin=generator_nonlin,
            generator_nonlin_out=self.encoder.activation_layout(
                discrete_activation=generator_nonlin_out_discrete,
                continuous_activation=generator_nonlin_out_continuous,
            ),
            generator_n_iter=generator_n_iter,
            generator_batch_norm=generator_batch_norm,
            generator_dropout=generator_dropout,
            generator_lr=generator_lr,
            generator_residual=generator_residual,
            generator_weight_decay=generator_weight_decay,
            generator_opt_betas=generator_opt_betas,
            generator_extra_penalties=generator_extra_penalties,
            generator_extra_penalty_cbks=[self._cond_loss],
            discriminator_n_layers_hidden=discriminator_n_layers_hidden,
            discriminator_n_units_hidden=discriminator_n_units_hidden,
            discriminator_n_iter=discriminator_n_iter,
            discriminator_nonlin=discriminator_nonlin,
            discriminator_batch_norm=discriminator_batch_norm,
            discriminator_dropout=discriminator_dropout,
            discriminator_lr=discriminator_lr,
            discriminator_weight_decay=discriminator_weight_decay,
            discriminator_opt_betas=discriminator_opt_betas,
            lambda_gradient_penalty=lambda_gradient_penalty,
            lambda_identifiability_penalty=lambda_identifiability_penalty,
            clipping_value=clipping_value,
            n_iter_print=n_iter_print,
            n_iter_min=n_iter_min,
            random_state=random_state,
            dataloader_sampler=dataloader_sampler,
            device=device,
            patience=patience,
            patience_metric=None,
        )

    def _cond_loss(
        self,
        real_samples: torch.Tensor,
        fake_samples: torch.Tensor,
        cond: Optional[torch.Tensor],
    ) -> torch.Tensor:
        """Conditional reconstruction loss for one-hot discrete features.

        No-op when the conditional is predefined (our case — Cancer Type is
        supplied externally rather than learned). Kept for API symmetry with
        the original SurvivalGAN paper, where the conditional could come from
        binning continuous features.

        IMPORTANT: This is a METHOD, not a local closure. Local closures
        defined inside __init__ are NOT picklable, which would break
        torch.save() of the model bundle.
        """
        if cond is None or self.predefined_conditional:
            return 0
        losses = []
        idx = 0
        cond_idx = 0
        for item in self.encoder.layout():
            length = item.output_dimensions
            if item.feature_type != "discrete":
                idx += length
                continue
            mask = cond[:, cond_idx:cond_idx + length].sum(dim=1).bool()
            if mask.sum() == 0:
                idx += length
                continue
            item_loss = nn.NLLLoss()(
                torch.log(fake_samples[mask, idx:idx + length] + 1e-8),
                torch.argmax(real_samples[mask, idx:idx + length], dim=1),
            )
            losses.append(item_loss)
            cond_idx += length
            idx += length
        if not losses:
            return 0
        return torch.stack(losses).sum() / len(real_samples)

    def fit(
        self,
        X: pd.DataFrame,
        cond: Optional[Union[pd.DataFrame, pd.Series, np.ndarray]] = None,
    ) -> "TabularGAN":
        X_enc = self.encoder.transform(X)

        if cond is not None and self.cond_encoder is not None:
            cond = np.asarray(cond)
            if len(cond.shape) == 1:
                cond = cond.reshape(-1, 1)
            cond = self.cond_encoder.transform(cond)

        self.model.fit(np.asarray(X_enc), np.asarray(cond) if cond is not None else None)
        return self

    def generate(
        self, count: int,
        cond: Optional[Union[pd.DataFrame, pd.Series, np.ndarray]] = None,
    ) -> pd.DataFrame:
        if cond is not None and self.cond_encoder is not None:
            cond = np.asarray(cond)
            if len(cond.shape) == 1:
                cond = cond.reshape(-1, 1)
            cond = self.cond_encoder.transform(cond)

        raw = self.model.generate(count, cond=cond)
        return self.encoder.inverse_transform(pd.DataFrame(raw))


# =========================================================================== #
#  Imbalanced sampler (kept for parity with the original code)                 #
# =========================================================================== #

class ImbalancedSampler(Sampler):
    """Oversamples underrepresented label groups.
    Compatible with PyTorch DataLoader's `sampler` argument."""

    def __init__(self, labels: list):
        self.labels = labels
        unique, counts = np.unique(labels, return_counts=True, axis=0)
        label_to_weight = {tuple(np.atleast_1d(u)): 1.0 / c for u, c in zip(unique, counts)}
        self.weights = np.array([
            label_to_weight[tuple(np.atleast_1d(l))] for l in labels
        ])
        self.weights /= self.weights.sum()
        self.n = len(labels)

    def __iter__(self):
        idxs = np.random.choice(self.n, size=self.n, replace=True, p=self.weights)
        return iter(idxs.tolist())

    def __len__(self):
        return self.n
