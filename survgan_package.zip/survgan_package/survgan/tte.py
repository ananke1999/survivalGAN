"""
Two-stage time-to-event model (DeepHit + XGBoost log-time regressor).

Lifted unchanged from the user's original survGAN.py — same fix for log(0)
poisoning, same residual-noise injection, same training-bound clamping.

The DeepHit dependency comes from synthcity's plugin registry.
"""

import logging
from typing import Any

import numpy as np
import pandas as pd
from xgboost import XGBRegressor

from synthcity.plugins.core.models.survival_analysis import (
    get_model_template as get_surv_model_template,
)


log = logging.getLogger(__name__)


class LocalSurvivalFunctionTTE:
    """
    Two-stage TTE:
      Stage 1: DeepHit learns S(t|X)
      Stage 2: XGBRegressor predicts log(T) from [X, S(t|X), E]
    """

    def __init__(self, device: Any = "cpu", time_points: int = 100,
                 n_estimators: int = 500, max_depth: int = 6,
                 add_residual_noise: bool = True,
                 noise_scale: float = 0.5,
                 clamp_margin: float = 0.05):

        self.device = device
        self.time_points = time_points
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.add_residual_noise = add_residual_noise
        self.noise_scale = noise_scale
        self.clamp_margin = clamp_margin

        # DeepHit hyperparameters from the SurvivalGAN paper.
        self.surv_model = get_surv_model_template("deephit")(
            device=device,
            num_durations=100,
            batch_size=100,
            epochs=2000,
            lr=1e-3,
            dim_hidden=300,
            alpha=0.28,
            sigma=0.38,
            dropout=0.02,
            patience=20,
            batch_norm=True,
        )

        self.tte_regressor = None
        self.time_horizons = None
        self._residual_std = 0.0
        # log-time bounds learned from training data — used to clamp predictions
        # so that OOD synthetic covariates can't produce times in the millions.
        self._Tlog_min = None
        self._Tlog_max = None
        self._T_min = None
        self._T_max = None

    def fit(self, X: pd.DataFrame, T: pd.Series, Y: pd.Series) -> "LocalSurvivalFunctionTTE":
        # Stage 1
        self.surv_model.fit(X, T, Y)

        self.time_horizons = np.linspace(T.min(), T.max(), self.time_points).tolist()

        surv_fn = self.surv_model.predict(X, time_horizons=self.time_horizons)
        surv_fn = surv_fn.loc[:, ~surv_fn.columns.duplicated()]

        data = X.copy()
        data[surv_fn.columns] = surv_fn
        data["_event_indicator"] = Y

        # Guard against T <= 0 in training data; log(0 + 1e-8) = -18.42 poisons
        # the regression target.
        T_pos = T.clip(lower=1e-3)
        Tlog = np.log(T_pos)

        xgb_params = {
            "n_jobs": 2,
            "n_estimators": self.n_estimators,
            "verbosity": 0,
            "max_depth": self.max_depth,
            "booster": "gbtree",
            "tree_method": "hist",
            "random_state": 0,
        }

        self.tte_regressor = XGBRegressor(**xgb_params).fit(data, Tlog)

        pred_log = self.tte_regressor.predict(data)
        self._residual_std = float(np.std(Tlog.values - pred_log))

        self._Tlog_min = float(Tlog.min())
        self._Tlog_max = float(Tlog.max())
        self._T_min = float(T_pos.min())
        self._T_max = float(T_pos.max())

        log.info(
            f"TTE fit: T=[{self._T_min:.3f}, {self._T_max:.3f}]  "
            f"logT=[{self._Tlog_min:.3f}, {self._Tlog_max:.3f}]  "
            f"residual_std(log)={self._residual_std:.4f}  "
            f"noise={'on' if self.add_residual_noise else 'off'}"
        )

        return self

    def predict(self, X: pd.DataFrame) -> pd.Series:
        return self.predict_any(X, pd.Series([1] * len(X), index=X.index))

    def _get(self, name: str, default: Any) -> Any:
        return getattr(self, name, default) if name in self.__dict__ else default

    def predict_any(self, X: pd.DataFrame, E: pd.Series) -> pd.Series:
        surv_fn = self.surv_model.predict(X, time_horizons=self.time_horizons)
        surv_fn = surv_fn.loc[:, ~surv_fn.columns.duplicated()]

        data = X.copy()
        data[surv_fn.columns] = surv_fn
        data["_event_indicator"] = E

        pred_log = np.asarray(self.tte_regressor.predict(data), dtype=float)

        add_noise = self._get("add_residual_noise", True)
        noise_scale = self._get("noise_scale", 0.5)
        clamp_margin = self._get("clamp_margin", 0.05)
        Tlog_min = self._get("_Tlog_min", None)
        Tlog_max = self._get("_Tlog_max", None)

        if add_noise and self._residual_std > 0:
            pred_log = pred_log + np.random.normal(
                0, self._residual_std * noise_scale, size=len(pred_log)
            )

        if Tlog_min is not None and Tlog_max is not None:
            span = max(Tlog_max - Tlog_min, 1e-6)
            lo = Tlog_min - clamp_margin * span
            hi = Tlog_max + clamp_margin * span
            pre_clip_low = int((pred_log < lo).sum())
            pre_clip_high = int((pred_log > hi).sum())
            pred_log = np.clip(pred_log, lo, hi)
            if pre_clip_low + pre_clip_high > 0:
                log.info(
                    f"TTE predict: clamped {pre_clip_low} below / "
                    f"{pre_clip_high} above log-T range "
                    f"[{lo:.3f}, {hi:.3f}] (of {len(pred_log)} total)"
                )

        out = np.exp(pred_log)
        if self._T_min is not None and self._T_max is not None:
            out = np.clip(out, self._T_min * 0.5, self._T_max * 2.0)

        return pd.Series(out, index=X.index)


def retrofit_tte_bounds(tte: "LocalSurvivalFunctionTTE",
                        T_train: pd.Series,
                        add_residual_noise: bool = True,
                        noise_scale: float = 0.5,
                        clamp_margin: float = 0.05) -> "LocalSurvivalFunctionTTE":
    """Patch a fitted TTE model with new log-time bounds. Used when loading
    older checkpoints that were trained before the clamping fix."""
    T_pos = T_train.clip(lower=1e-3)
    Tlog = np.log(T_pos)
    tte._Tlog_min = float(Tlog.min())
    tte._Tlog_max = float(Tlog.max())
    tte._T_min = float(T_pos.min())
    tte._T_max = float(T_pos.max())
    tte.add_residual_noise = add_residual_noise
    tte.noise_scale = noise_scale
    tte.clamp_margin = clamp_margin
    log.info(
        f"retrofit_tte_bounds: T=[{tte._T_min:.3f}, {tte._T_max:.3f}]  "
        f"logT=[{tte._Tlog_min:.3f}, {tte._Tlog_max:.3f}]  "
        f"noise={'on' if tte.add_residual_noise else 'off'}"
    )
    return tte
