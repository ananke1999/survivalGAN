"""Shared utilities: reproducibility seeding + device detection."""

import os
import logging
import random

import numpy as np
import torch

log = logging.getLogger(__name__)


def seed_everything(seed: int) -> None:
    """Set every random seed we know about. Call this once at process start."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


def setup_device(preference: str = "auto") -> str:
    """Resolve a device string ("auto" | "cuda" | "cpu") to "cuda" or "cpu".

    Auto picks CUDA when available; otherwise CPU. Returns the chosen string
    and turns on cudnn benchmark when CUDA is selected (small speedup for
    the GAN's repeated forward/backward passes on fixed-size batches).
    """
    if preference == "auto":
        use_cuda = torch.cuda.is_available()
    else:
        use_cuda = (preference == "cuda") and torch.cuda.is_available()

    if use_cuda:
        torch.backends.cudnn.benchmark = True
        name = torch.cuda.get_device_name(0)
        mem = torch.cuda.get_device_properties(0).total_memory / 1e9
        log.info(f"GPU: {name} ({mem:.1f} GB)")
        return "cuda"

    log.info("Using CPU")
    return "cpu"
