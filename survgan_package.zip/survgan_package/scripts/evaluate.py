#!/usr/bin/env python3
"""
scripts/evaluate.py — run the synthcity-based evaluation suite on a
synthetic CSV produced by SurvivalGAN.

This is just a thin convenience wrapper around evaluate_synthetic_data.py at
the package root. All real work happens there. We default to the standard
column names (`time`, `status`) used by SurvivalGANModel.

Example:
    python scripts/evaluate.py \\
        --real-train  runs/breast_full/prepared/survival_gan_train.csv \\
        --real-test   runs/breast_full/prepared/survival_gan_test.csv \\
        --synthetic   runs/breast_full/synthetic.csv \\
        --outdir      runs/breast_full/eval

If you want full control (extra metrics, custom column maps, etc.), just call
evaluate_synthetic_data.py directly — it has a much richer CLI surface.
"""

import argparse
import subprocess
import sys
from pathlib import Path


_PKG_ROOT = Path(__file__).resolve().parent.parent
_EVAL_SCRIPT = _PKG_ROOT / "evaluate_synthetic_data.py"


def main() -> int:
    p = argparse.ArgumentParser(description="Wrapper around evaluate_synthetic_data.py")
    p.add_argument("--real-train", required=True)
    p.add_argument("--real-test",  required=True)
    p.add_argument("--synthetic",  required=True)
    p.add_argument("--outdir",     required=True)
    p.add_argument("--time-column",   default="time")
    p.add_argument("--status-column", default="status")
    p.add_argument("--", dest="extra", nargs=argparse.REMAINDER,
                   help="Extra args passed through to evaluate_synthetic_data.py")
    args = p.parse_args()

    if not _EVAL_SCRIPT.exists():
        print(f"ERROR: {_EVAL_SCRIPT} not found.", file=sys.stderr)
        return 2

    cmd = [
        sys.executable, str(_EVAL_SCRIPT),
        "--real-train",    args.real_train,
        "--real-test",     args.real_test,
        "--synthetic",     args.synthetic,
        "--time-column",   args.time_column,
        "--status-column", args.status_column,
        "--outdir",        args.outdir,
    ]
    if args.extra:
        # argparse's REMAINDER captures the leading "--" — drop it
        extra = [a for a in args.extra if a != "--"]
        cmd.extend(extra)

    print("Running:", " ".join(cmd))
    return subprocess.call(cmd)


if __name__ == "__main__":
    sys.exit(main())
