#!/usr/bin/env python3
"""
scripts/train.py — train a cancer-type-conditional SurvivalGAN on MSK-IMPACT 50K.

Two-step pipeline:
  1. Run preprocessing on the raw CSV (or load from a pre-prepared train CSV).
  2. Fit SurvivalGANModel with the user-selected covariate subset.

Outputs (per run, into --output-dir):
  - model.pt              — full SurvivalGANModel bundle
  - synthetic.csv         — generated synthetic patients
  - train.log             — full training log

Example:
    python scripts/train.py \\
        --raw-csv data/msk_impact_50K.csv \\
        --output-dir runs/breast_full \\
        --covariates "Age at Diagnosis,Sex,Mutation Count,TMB Score" \\
        --n-iter 2500 \\
        --batch-size 256 \\
        --synthetic-count 5000

To use ALL 17 covariates pass --covariates all.

To filter the training data to a subset of cancer types (e.g. focus the model
on common types), pass --train-cancer-types "Breast Cancer,Lung Adenocarcinoma".
By default we train on all 16 cancer types (top-15 + Other).
"""

import argparse
import logging
import sys
import time
import traceback
from pathlib import Path

import pandas as pd
import torch

# Add the package root to sys.path so `python scripts/train.py` works without
# needing `pip install -e .`. Removes one setup step for the user.
_PKG_ROOT = Path(__file__).resolve().parent.parent
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

from survgan import (
    SurvivalGANModel,
    prepare_data,
    seed_everything,
    setup_device,
)
from survgan.model import SurvivalGANConfig


# Default covariate set (the 17 features that survive preprocessing).
ALL_COVARIATES = [
    "Age at Diagnosis", "Genetic Ancestry", "Disease Status",
    "Ploidy (FACETS)", "FACETS Estimated Purity", "FACETS QC",
    "Whole Genome Doubling Status (FACETS)", "Fraction Genome Altered",
    "MSI Score", "MSI Type", "Mutation Count", "Number of Other Cancer Types",
    "Sample coverage", "Sex", "TMB Score", "Pathologist Estimated Tumor Purity",
]
# Note: "Cancer Type" is the conditional, not a covariate — excluded from the list.


def setup_logging(log_path: Path) -> None:
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    for h in list(root.handlers):
        root.removeHandler(h)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    fh = logging.FileHandler(log_path, mode="a")
    fh.setFormatter(fmt)
    root.addHandler(fh)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    root.addHandler(sh)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Train SurvivalGAN (conditional on Cancer Type) on MSK-IMPACT 50K",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # I/O — accept either a raw CSV (run preprocessing) or pre-prepared train CSV.
    p.add_argument("--raw-csv", help="Path to msk_impact_50K.csv (will be preprocessed).")
    p.add_argument("--prepared-train-csv",
                   help="Path to a pre-prepared train CSV (skip preprocessing).")
    p.add_argument("--output-dir", required=True,
                   help="Where to write model.pt, synthetic.csv, and train.log.")

    # Model setup
    p.add_argument("--covariates", default="all",
                   help="Comma-separated covariate names, or 'all' for all 17. "
                        "Cancer Type is always the conditional and is not in this list.")
    p.add_argument("--train-cancer-types", default="all",
                   help="Comma-separated cancer types to KEEP in training data, "
                        "or 'all' for the full top-15 + Other.")
    p.add_argument("--time-column", default="time")
    p.add_argument("--status-column", default="status")
    p.add_argument("--cancer-type-column", default="Cancer Type")

    # Training
    p.add_argument("--n-iter", type=int, default=2500)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])

    # Generation (post-training)
    p.add_argument("--synthetic-count", type=int, default=None,
                   help="How many synthetic samples to write. Defaults to n_train.")
    p.add_argument("--generate-cancer-type", default=None,
                   help="If set, all generated samples will have this cancer type. "
                        "Otherwise cancer types are sampled from the training distribution.")
    p.add_argument("--no-synthetic", action="store_true",
                   help="Skip generation step (just save the model.pt).")

    return p.parse_args()


def resolve_covariates(arg: str) -> list:
    if arg.strip().lower() == "all":
        return ALL_COVARIATES.copy()
    cols = [c.strip() for c in arg.split(",") if c.strip()]
    unknown = [c for c in cols if c not in ALL_COVARIATES]
    if unknown:
        raise ValueError(
            f"Unknown covariate(s): {unknown}\nAllowed: {ALL_COVARIATES}"
        )
    return cols


def filter_cancer_types(df: pd.DataFrame, arg: str, col: str,
                        label_encoder, log: logging.Logger) -> pd.DataFrame:
    """Filter df to rows whose Cancer Type is in the comma-separated `arg`.

    Cancer Type is integer-encoded after preprocessing, so we use the
    LabelEncoder (when available) to map the user-supplied strings to int
    codes. If the column is already strings (rare), we filter on strings.
    """
    if arg.strip().lower() == "all":
        return df

    keep_names = [c.strip() for c in arg.split(",") if c.strip()]
    n_before = len(df)

    if df[col].dtype.kind in "iu":
        # Integer-encoded — need the label encoder to map names → codes
        if label_encoder is None:
            log.warning(
                f"--train-cancer-types: column '{col}' is integer-encoded but "
                f"no LabelEncoder is available; cannot filter by name. "
                f"Either run with --raw-csv (preprocessing produces an encoder) "
                f"or pass integer codes directly. Skipping filter."
            )
            return df
        known = set(label_encoder.classes_)
        unknown = [n for n in keep_names if n not in known]
        if unknown:
            log.warning(
                f"--train-cancer-types: these names are not in the label "
                f"encoder and will be ignored: {unknown}\n"
                f"Known cancer types: {list(label_encoder.classes_)}"
            )
        keep_names = [n for n in keep_names if n in known]
        if not keep_names:
            raise ValueError(
                f"--train-cancer-types: no valid cancer types after filtering. "
                f"Got: {arg}"
            )
        keep_codes = label_encoder.transform(keep_names).tolist()
        df = df[df[col].isin(keep_codes)].reset_index(drop=True)
    else:
        # String column — direct match
        df = df[df[col].isin(keep_names)].reset_index(drop=True)

    log.info(
        f"Cancer-type filter '{arg}' → kept {len(df)}/{n_before} rows "
        f"(types: {keep_names})"
    )
    return df


def main() -> int:
    args = parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    log_path = out_dir / "train.log"
    setup_logging(log_path)
    log = logging.getLogger("train")

    log.info("=" * 70)
    log.info("SurvivalGAN training (cancer-type-conditional)")
    log.info(f"Args: {vars(args)}")
    log.info(f"PyTorch: {torch.__version__} | CUDA available: {torch.cuda.is_available()}")
    log.info("=" * 70)

    seed_everything(args.seed)
    device = setup_device(args.device)

    # ------------------------------------------------------------------ #
    #  Step 1: Get the training DataFrame                                 #
    # ------------------------------------------------------------------ #

    metadata = None
    if args.raw_csv:
        log.info(f"Preprocessing raw CSV {args.raw_csv} ...")
        prep_dir = out_dir / "prepared"
        df_train, df_test, metadata = prepare_data(
            raw_csv_path=args.raw_csv,
            out_dir=str(prep_dir),
            random_seed=args.seed,
        )
    elif args.prepared_train_csv:
        log.info(f"Loading prepared train CSV {args.prepared_train_csv} ...")
        df_train = pd.read_csv(args.prepared_train_csv)
        log.info(f"Train: {df_train.shape}")
        # Check whether a metadata JSON is sitting next to it
        meta_guess = Path(args.prepared_train_csv).parent / "survival_gan_column_metadata.json"
        if meta_guess.exists():
            import json
            with open(meta_guess) as f:
                meta_json = json.load(f)
            metadata = {
                "column_metadata": meta_json.get("columns", {}),
                "label_encoders": {},  # not available — generate() will fall back to int codes
            }
            log.info(f"Loaded column metadata from {meta_guess}")
        else:
            log.warning(
                "No metadata JSON found next to the prepared train CSV. "
                "Cancer type strings won't be available — pass int codes to generate()."
            )
            metadata = {"column_metadata": {}, "label_encoders": {}}
    else:
        log.error("Must specify either --raw-csv or --prepared-train-csv")
        return 2

    # Optional: filter to a subset of cancer types
    ct_label_encoder = (
        metadata["label_encoders"].get(args.cancer_type_column) if metadata else None
    )
    df_train = filter_cancer_types(
        df_train, args.train_cancer_types, args.cancer_type_column,
        ct_label_encoder, log,
    )

    # ------------------------------------------------------------------ #
    #  Step 2: Resolve covariates                                         #
    # ------------------------------------------------------------------ #

    covariates = resolve_covariates(args.covariates)
    # Warn about any covariates the prepared df doesn't actually have (e.g.
    # they got dropped during preprocessing for high missingness).
    missing = [c for c in covariates if c not in df_train.columns]
    if missing:
        log.warning(
            f"These requested covariates aren't in the data and will be skipped: {missing}"
        )
        covariates = [c for c in covariates if c in df_train.columns]
    log.info(f"Using {len(covariates)} covariates: {covariates}")

    # ------------------------------------------------------------------ #
    #  Step 3: Build & fit the model                                      #
    # ------------------------------------------------------------------ #

    cfg = SurvivalGANConfig(
        n_iter=args.n_iter,
        batch_size=args.batch_size,
        seed=args.seed,
    )

    model = SurvivalGANModel(
        covariates=covariates,
        cancer_type_column=args.cancer_type_column,
        time_column=args.time_column,
        status_column=args.status_column,
        cancer_type_label_encoder=(
            metadata["label_encoders"].get(args.cancer_type_column)
            if metadata else None
        ),
        column_metadata=metadata.get("column_metadata", {}) if metadata else {},
        config=cfg,
        device=device,
    )

    log.info("Starting model.fit() ...")
    t0 = time.time()
    try:
        model.fit(df_train)
    except KeyboardInterrupt:
        log.warning("Interrupted by user during fit()")
        return 130
    except Exception:
        log.error("fit() crashed; full traceback:")
        log.error(traceback.format_exc())
        return 1
    log.info(f"Training finished in {(time.time() - t0)/60:.1f} min")

    if torch.cuda.is_available():
        log.info(f"Peak GPU memory: {torch.cuda.max_memory_allocated() / 1e9:.2f} GB")

    # ------------------------------------------------------------------ #
    #  Step 4: Save model                                                 #
    # ------------------------------------------------------------------ #

    pt_path = out_dir / "model.pt"
    model.save_pt(pt_path)

    # ------------------------------------------------------------------ #
    #  Step 5: Generate synthetic data (unless --no-synthetic)            #
    # ------------------------------------------------------------------ #

    if args.no_synthetic:
        log.info("--no-synthetic set; skipping generation.")
        return 0

    n_syn = args.synthetic_count or len(df_train)
    log.info(f"Generating {n_syn} synthetic samples ...")
    try:
        syn_df = model.generate(
            n_samples=n_syn,
            cancer_type=args.generate_cancer_type,
            real_df_for_precision=df_train,
            seed=args.seed,
        )
    except Exception:
        log.error("generate() crashed; full traceback:")
        log.error(traceback.format_exc())
        return 1

    syn_path = out_dir / "synthetic.csv"
    syn_df.to_csv(syn_path, index=False)
    log.info(f"Wrote synthetic data → {syn_path}  ({syn_df.shape})")

    # ------------------------------------------------------------------ #
    #  Step 6: Quick real-vs-synthetic sanity dump                        #
    # ------------------------------------------------------------------ #

    log.info("=== Real vs Synthetic means (numeric cols) ===")
    for col in syn_df.columns:
        if col not in df_train.columns:
            continue
        try:
            r = pd.to_numeric(df_train[col], errors="coerce").mean()
            s = pd.to_numeric(syn_df[col], errors="coerce").mean()
            if pd.isna(r) or pd.isna(s):
                continue
            rel_diff = abs(r - s) / (abs(r) + 1e-8) * 100
            log.info(f"  {col:36s}  real={r:10.3f}  synth={s:10.3f}  diff={rel_diff:5.1f}%")
        except Exception:
            continue

    log.info("Done.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
