#!/usr/bin/env python3
"""
scripts/generate.py — load a trained SurvivalGAN .pt and emit synthetic samples.

Usage:
    python scripts/generate.py \\
        --model-pt runs/breast_full/model.pt \\
        --cancer-type "Breast Cancer" \\
        --n-samples 1000 \\
        --output-csv synthetic_breast.csv

If --cancer-type is omitted, cancer types are sampled from the model's
training distribution.

If --real-csv is provided we use it for precision matching (recommended for
fair evaluation against the real held-out test set).
"""

import argparse
import logging
import sys
from pathlib import Path

import pandas as pd

_PKG_ROOT = Path(__file__).resolve().parent.parent
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

from survgan import SurvivalGANModel, seed_everything, setup_device


logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("generate")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Generate synthetic samples from a trained SurvivalGAN .pt")
    p.add_argument("--model-pt", required=True, help="Path to model.pt")
    p.add_argument("--output-csv", required=True, help="Where to write synthetic CSV")
    p.add_argument("--cancer-type", default=None,
                   help="Cancer type string (e.g. 'Breast Cancer'). "
                        "If omitted, cancer types are sampled from training distribution.")
    p.add_argument("--n-samples", type=int, default=1000)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    p.add_argument("--real-csv", default=None,
                   help="Optional: path to a real CSV used for precision matching.")
    p.add_argument("--list-cancer-types", action="store_true",
                   help="Just print available cancer types and exit.")
    return p.parse_args()


def main() -> int:
    args = parse_args()

    seed_everything(args.seed)
    device = setup_device(args.device)

    log.info(f"Loading model from {args.model_pt} ...")
    model = SurvivalGANModel.load_pt(args.model_pt, device=device)

    if args.list_cancer_types:
        print("Available cancer types:")
        for ct in model.list_cancer_types():
            print(f"  - {ct}")
        return 0

    real_df = None
    if args.real_csv:
        log.info(f"Loading real CSV for precision matching: {args.real_csv}")
        real_df = pd.read_csv(args.real_csv)

    log.info(f"Generating {args.n_samples} samples (cancer_type={args.cancer_type}) ...")
    syn_df = model.generate(
        n_samples=args.n_samples,
        cancer_type=args.cancer_type,
        seed=args.seed,
        real_df_for_precision=real_df,
    )

    out = Path(args.output_csv)
    out.parent.mkdir(parents=True, exist_ok=True)
    syn_df.to_csv(out, index=False)
    log.info(f"Wrote {syn_df.shape} → {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
