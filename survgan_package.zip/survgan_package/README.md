# SurvivalGAN — Cancer-Type-Conditional Synthetic Patient Data

A deployable package for training and serving a **SurvivalGAN** that generates
synthetic patient records (covariates + survival outcome) on the
[MSK-IMPACT 50K](https://www.cbioportal.org/study/summary?id=msk_impact_2017)
clinical-genomic dataset.

This repository wraps the user's research code into a clean
training → save → load → generate workflow with:

- **Cancer-type conditioning** — one model, conditioned on cancer type at
  inference (no need to train 16 separate models).
- **`.pt` save/load** — fully self-contained model bundle (GAN weights,
  TTE model, encoders, label encoder for cancer types). One file to ship.
- **Hugging Face Inference Endpoint handler** — `handler.py` exposes a
  JSON-only API. No frontend ships with the package.
- **Subset-of-covariates training** — preprocessing keeps all 19 columns,
  but you tell the GAN to model only the subset you care about.

> ⚠️ This is a **research code package**, not a production medical-grade
> system. Synthetic patients should not be used clinically. The GAN is also
> not formally privacy-protected (no DP); the SurvivalGAN paper's identifiability
> penalty is included but not a substitute for proper privacy auditing.

---

## Install

```bash
# Create a fresh conda env (recommended)
conda create -n survivalgan python=3.10 -y
conda activate survivalgan

# Install dependencies
pip install -r requirements.txt
```

Notes:
- The `torch<2.3` cap is required by synthcity. If you ever bump it, you'll
  need to also update `opacus` away from 1.4.0.
- DeepHit (used by the TTE model) ships with synthcity — no separate install.

---

## Quick start (3 steps)

### 1. Preprocess the raw CSV

```bash
python -c "
from survgan import prepare_data
df_train, df_test, meta = prepare_data(
    raw_csv_path='data/msk_impact_50K.csv',
    out_dir='runs/exp1/prepared',
)
print(f'Train: {df_train.shape}, Test: {df_test.shape}')
print(f'Cancer types: {meta[\"cancer_types\"]}')
"
```

This produces `runs/exp1/prepared/{survival_gan_train.csv, survival_gan_test.csv, survival_gan_column_metadata.json}`.

### 2. Train + save model + emit synthetic CSV

```bash
python scripts/train.py \
    --raw-csv data/msk_impact_50K.csv \
    --output-dir runs/exp1 \
    --covariates "Age at Diagnosis,Sex,Mutation Count,TMB Score,MSI Score" \
    --n-iter 2500 \
    --batch-size 256 \
    --synthetic-count 5000
```

Outputs (in `runs/exp1/`):
- `model.pt` — full SurvivalGANModel bundle (~20-50 MB)
- `synthetic.csv` — 5000 generated patients (cancer types sampled from training distribution)
- `train.log` — full log

### 3. Evaluate

```bash
python scripts/evaluate.py \
    --real-train  runs/exp1/prepared/survival_gan_train.csv \
    --real-test   runs/exp1/prepared/survival_gan_test.csv \
    --synthetic   runs/exp1/synthetic.csv \
    --outdir      runs/exp1/eval
```

This calls `evaluate_synthetic_data.py` with the standard column conventions
and writes metrics + plots into `runs/exp1/eval/`.

---

## CLI reference

### `scripts/train.py`

| Flag | Description | Default |
|------|-------------|---------|
| `--raw-csv` | Path to `msk_impact_50K.csv` (runs full preprocessing). | — |
| `--prepared-train-csv` | Use a pre-prepared train CSV (skip preprocessing). | — |
| `--output-dir` | **Required.** Where to write `model.pt`, `synthetic.csv`, `train.log`. | — |
| `--covariates` | Comma-separated covariate names, or `all` for all 17. Cancer Type is always the conditional, never a covariate. | `all` |
| `--train-cancer-types` | Comma-separated cancer types to keep, or `all`. | `all` |
| `--n-iter` | GAN training iterations. | `2500` |
| `--batch-size` | | `256` |
| `--device` | `auto`, `cuda`, or `cpu`. | `auto` |
| `--synthetic-count` | How many synthetic samples to write after training. | `n_train` |
| `--generate-cancer-type` | If set, all generated samples will have this cancer type. | None (sample from training distribution) |
| `--no-synthetic` | Just save the model.pt; don't generate. | False |

The 17 valid covariates are:

```
Age at Diagnosis, Genetic Ancestry, Disease Status, Ploidy (FACETS),
FACETS Estimated Purity, FACETS QC, Whole Genome Doubling Status (FACETS),
Fraction Genome Altered, MSI Score, MSI Type, Mutation Count,
Number of Other Cancer Types, Sample coverage, Sex, TMB Score,
Pathologist Estimated Tumor Purity
```
(`Cancer Type`, `time`, `status` are managed automatically.)

### `scripts/generate.py`

| Flag | Description |
|------|-------------|
| `--model-pt` | Path to a saved model.pt. **Required.** |
| `--output-csv` | Where to write the synthetic CSV. **Required.** |
| `--cancer-type` | Cancer type to condition on. If omitted, sampled from training distribution. |
| `--n-samples` | How many to generate (default 1000). |
| `--real-csv` | Optional. Real CSV used for precision matching. |
| `--list-cancer-types` | Print available cancer types and exit. |

---

## Hugging Face deployment

### Repository layout

Push these files to a HuggingFace model repository (e.g. `your-username/survivalgan-msk-50k`):

```
.
├── handler.py            # the EndpointHandler class
├── requirements.txt
├── model.pt              # produced by scripts/train.py
└── survgan/              # the package directory
    ├── __init__.py
    ├── model.py
    ├── pipeline.py
    ├── tte.py
    ├── preprocessing.py
    ├── constraints.py
    └── utils.py
```

**Crucial:** the `survgan/` directory must be uploaded alongside `handler.py`.
`SurvivalGANModel.load_pt()` deserializes pickled objects whose classes live
in this package, so the package code has to be importable on the endpoint.

### Deploy

Create an Inference Endpoint pointing at your model repo. Choose **Custom**
container type. HF will instantiate `EndpointHandler(path)` once at warm-up
and call its `__call__(data)` on each request.

### API

#### Generate synthetic samples

```bash
curl -X POST https://<your-endpoint>.endpoints.huggingface.cloud \
    -H "Authorization: Bearer $HF_TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
        "inputs": {
            "cancer_type": "Breast Cancer",
            "n_samples": 100,
            "seed": 42
        }
    }'
```

Response:
```json
{
    "data": [
        {"Age at Diagnosis": 67, "Sex": "Female", "Mutation Count": 12,
         "TMB Score": 4.5, "time": 38.2, "status": 0, "Cancer Type": "Breast Cancer"},
        ...
    ],
    "n_samples": 100,
    "cancer_type": "Breast Cancer",
    "columns": ["Age at Diagnosis", "Sex", "Mutation Count", "TMB Score",
                "time", "status", "Cancer Type"]
}
```

#### Discover what the model supports

```bash
curl -X POST <endpoint> -d '{"inputs": {"info": true}}'
# → covariates, available cancer types, version, training column order
```

```bash
curl -X POST <endpoint> -d '{"inputs": {"list_cancer_types": true}}'
# → just the list of cancer types
```

### Caps

- `MAX_N_SAMPLES = 10000` per request (in `handler.py`). Bump this if you
  need more — the model runs fast enough on CPU.
- `cancer_type=null` is allowed and means "sample from the training-time
  cancer-type distribution". Useful for bulk synthetic-cohort generation.

---

## Architecture

### What the conditional model does

The original SurvivalGAN paper conditions the GAN on a binned encoding of
**all** covariates plus T and E. This package replaces that with a simpler
**Cancer-Type** conditional:

```
conditional vector = OneHot(Cancer Type)
GAN learns:           p(other_covariates, time, status | cancer_type)
```

At inference, you supply a cancer type and the GAN produces samples from
the corresponding conditional distribution. This is what gives you "1 model,
16 cancer types" instead of "16 separate models".

### What's in the `.pt` bundle

`SurvivalGANModel.save_pt()` writes via `torch.save()` (which uses pickle).
The bundle contains:

| Key | What |
|-----|------|
| `version` | bundle version string (currently `"1.0"`) |
| `config` | full `SurvivalGANConfig` dict |
| `covariates` | the user-chosen subset |
| `cancer_type_column`, `time_column`, `status_column` | column names |
| `cancer_type_classes` | the int codes the GAN was trained on |
| `cancer_type_label_encoder` | sklearn `LabelEncoder` (string ↔ code) |
| `column_metadata` | per-column dtype + bounds for constraint enforcement |
| `training_columns` | the column order the GAN expects |
| `gan` | full `TabularGAN` (encoders + nn.Module weights) |
| `tte_model` | DeepHit + XGBoost log-T regressor + log-T bounds |
| `censoring_predictor` | XGBClassifier for covariate-dependent censoring |

> ⚠️ **Security note.** Loading the `.pt` bundle requires
> `torch.load(weights_only=False)` because the bundle contains pickled
> XGBoost/sklearn objects. Only load `.pt` files you trust.

### Departures from the original code

This package replaces `SurvivalPipeline` (from the original `survGAN.py`) with
a cleaner `SurvivalGANModel` class. Two notable behavior changes:

1. The conditional vector is **only** Cancer Type, not the paper's binned
   covariates+T+E. If you want the paper's original conditioning back, you'd
   re-introduce the `BinEncoder` step.
2. Cancer Type is **always** mandatory. The training data must include a
   Cancer Type column.

All bug fixes from the original code are preserved (log-time clamping,
integer-dtype rounding before cast, T<=0 protection in TTE training, etc.).

---

## Programmatic API

```python
from survgan import SurvivalGANModel, prepare_data
from survgan.model import SurvivalGANConfig

# 1. Preprocess
df_train, df_test, meta = prepare_data(
    "data/msk_impact_50K.csv",
    out_dir="runs/exp1/prepared",
)

# 2. Train
model = SurvivalGANModel(
    covariates=["Age at Diagnosis", "Sex", "TMB Score"],
    cancer_type_column="Cancer Type",
    cancer_type_label_encoder=meta["label_encoders"]["Cancer Type"],
    column_metadata=meta["column_metadata"],
    config=SurvivalGANConfig(n_iter=2500, batch_size=256),
    device="cuda",
)
model.fit(df_train)
model.save_pt("runs/exp1/model.pt")

# 3. Generate (any time, on any machine with this package)
model = SurvivalGANModel.load_pt("runs/exp1/model.pt", device="cpu")
syn = model.generate(n_samples=500, cancer_type="Breast Cancer")
syn.to_csv("synthetic_breast.csv", index=False)
```

---

## Project structure

```
survgan_package/
├── survgan/
│   ├── __init__.py
│   ├── model.py            # SurvivalGANModel — the public API
│   ├── pipeline.py         # core GAN: TabularGAN, GAN, encoders
│   ├── tte.py              # LocalSurvivalFunctionTTE (DeepHit + XGBoost)
│   ├── preprocessing.py    # prepare_data(): MSK-IMPACT cleaning
│   ├── constraints.py      # match_real_precision, enforce_physical_constraints
│   └── utils.py            # seed_everything, setup_device
├── scripts/
│   ├── train.py            # CLI: preprocess + train + (optionally) generate
│   ├── generate.py         # CLI: load .pt, emit synthetic CSV
│   └── evaluate.py         # CLI: thin wrapper around evaluate_synthetic_data.py
├── handler.py              # HuggingFace Inference Endpoint handler
├── evaluate_synthetic_data.py   # synthcity-based evaluation suite
├── requirements.txt
└── README.md
```

---

## Common gotchas

- **`torch.load` warning about pickle.** Expected. The bundle is intentionally
  pickled. Load `.pt` files only from trusted sources.
- **DeepHit fails on a different device than it was trained on.** `load_pt()`
  patches `tte_model.surv_model.device` to the target, but if you see device
  mismatch errors, pass `device="cpu"` to `load_pt`.
- **OOM during training on full 17 covariates.** Drop `--batch-size` to 128.
  GMM encoding of high-cardinality continuous columns dominates memory.
- **Synthetic times are too clustered around the median.** The TTE has a
  `noise_scale` parameter (default 0.5). Bump to ~1.0 for more variance.
