"""
quickstart.py — minimal end-to-end SurvivalGAN demo using the programmatic API.

Run from the package root:
    python examples/quickstart.py

Edit RAW_CSV at the top to point at your local copy of msk_impact_50K.csv.
"""

import logging
import sys
from pathlib import Path

# Add package root to sys.path so `python examples/quickstart.py` works
_PKG_ROOT = Path(__file__).resolve().parent.parent
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

from survgan import SurvivalGANModel, prepare_data, seed_everything, setup_device
from survgan.model import SurvivalGANConfig


# Edit me ↓
RAW_CSV  = "data/msk_impact_50K.csv"
OUT_DIR  = Path("runs/quickstart")
N_ITER   = 200    # tiny for a quick demo; bump to 2500 for a real run
N_SAMPLES = 200


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    seed_everything(42)
    device = setup_device("auto")
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # Step 1: Preprocess raw CSV
    print("\n[1/4] Preprocessing raw CSV ...")
    df_train, df_test, meta = prepare_data(
        raw_csv_path=RAW_CSV,
        out_dir=str(OUT_DIR / "prepared"),
        random_seed=42,
    )
    print(f"  Train: {df_train.shape}, Test: {df_test.shape}")
    print(f"  Cancer types: {meta['cancer_types']}")

    # Step 2: Build + train the model on a small subset of covariates
    print("\n[2/4] Training SurvivalGAN (conditional on Cancer Type) ...")
    chosen_covariates = ["Age at Diagnosis", "Sex", "Mutation Count", "TMB Score"]

    model = SurvivalGANModel(
        covariates=chosen_covariates,
        cancer_type_column="Cancer Type",
        time_column="time",
        status_column="status",
        cancer_type_label_encoder=meta["label_encoders"]["Cancer Type"],
        column_metadata=meta["column_metadata"],
        config=SurvivalGANConfig(n_iter=N_ITER, batch_size=256),
        device=device,
    )
    model.fit(df_train)

    # Step 3: Save the .pt bundle
    print("\n[3/4] Saving model.pt ...")
    pt_path = OUT_DIR / "model.pt"
    model.save_pt(pt_path)

    # Step 4: Reload + generate
    print("\n[4/4] Loading from .pt and generating ...")
    model_loaded = SurvivalGANModel.load_pt(pt_path, device=device)
    print(f"  Available cancer types: {model_loaded.list_cancer_types()[:5]}...")

    # Generate samples for a specific cancer type
    syn = model_loaded.generate(
        n_samples=N_SAMPLES,
        cancer_type="Breast Cancer",
        seed=42,
        real_df_for_precision=df_train,
    )
    print(f"  Generated {len(syn)} samples for 'Breast Cancer'")
    print(f"  Columns: {syn.columns.tolist()}")
    print(f"  Sample row:\n    {syn.iloc[0].to_dict()}")

    syn_path = OUT_DIR / "synthetic_breast_cancer.csv"
    syn.to_csv(syn_path, index=False)
    print(f"  Wrote → {syn_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
