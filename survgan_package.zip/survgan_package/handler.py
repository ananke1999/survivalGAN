"""
Hugging Face Inference Endpoint handler.

Deploy this as the entry point of an HF Inference Endpoint by uploading:
    handler.py
    model.pt
    requirements.txt
    survgan/  (the package directory)

to a HuggingFace model repository, then deploying it as a "Custom" endpoint.
HF will instantiate `EndpointHandler(path)` once at warm-up, and call its
`__call__(data)` method on each request.

API
---

Request:
    POST /predict
    Content-Type: application/json
    {
        "inputs": {
            "cancer_type": "Breast Cancer",   // string OR int OR null (sample)
            "n_samples": 100,                  // 1-10000
            "seed": 42                         // optional
        }
    }

Response (success):
    {
        "data": [{"Age at Diagnosis": 67, "Sex": "Female", ...}, ...],
        "n_samples": 100,
        "cancer_type": "Breast Cancer",
        "columns": ["Age at Diagnosis", "Sex", ..., "time", "status", "Cancer Type"]
    }

Response (error):
    {"error": "Cancer type 'Foo Cancer' not in label encoder classes ..."}

The handler also supports a "info" mode for clients that want to know what the
model can produce:

    {"inputs": {"info": true}}
       → returns model.info() dict (covariates, available cancer types, etc.)
"""

import json
import logging
import sys
import traceback
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pandas as pd

# Ensure the `survgan` package next to this file is importable even when HF
# starts the handler from an arbitrary working directory.
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from survgan import SurvivalGANModel  # noqa: E402


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] handler: %(message)s",
)
log = logging.getLogger("handler")


# Caps to keep one request from monopolising the endpoint
MAX_N_SAMPLES = 10000
DEFAULT_N_SAMPLES = 100


class EndpointHandler:
    """HF Inference Endpoint handler interface.

    HF instantiates this once with `path` set to the directory containing the
    repository contents (model.pt and friends).
    """

    def __init__(self, path: str = ""):
        model_path = Path(path) / "model.pt"
        if not model_path.exists():
            # Fall back to looking next to the handler
            model_path = _HERE / "model.pt"
        if not model_path.exists():
            raise FileNotFoundError(
                f"Could not find model.pt at {Path(path) / 'model.pt'} "
                f"or {_HERE / 'model.pt'}"
            )

        log.info(f"Loading model from {model_path} ...")
        # Endpoint hosts may or may not give us a GPU; load to CPU and let
        # the user move it via a request flag if they want CUDA.
        self.model = SurvivalGANModel.load_pt(str(model_path), device="cpu")
        log.info(f"Model loaded. Info: {self.model.info()}")

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Single request handler.

        `data` is the parsed JSON body. HF passes the body as-is. We expect
        either {"inputs": {...}} or just {...}.
        """
        try:
            return self._handle(data)
        except Exception as e:
            log.error("Request failed: %s\n%s", e, traceback.format_exc())
            return {"error": str(e), "type": type(e).__name__}

    def _handle(self, data: Dict[str, Any]) -> Dict[str, Any]:
        inputs = data.get("inputs", data) or {}
        if isinstance(inputs, str):
            inputs = json.loads(inputs)

        # /info shortcut — tell the caller what cancer types and covariates
        # this model supports.
        if inputs.get("info"):
            return self.model.info()

        # /list_cancer_types shortcut — same idea, just the list
        if inputs.get("list_cancer_types"):
            return {"cancer_types": self.model.list_cancer_types()}

        # ---- Generation request ----
        cancer_type = inputs.get("cancer_type", None)
        n_samples = int(inputs.get("n_samples", DEFAULT_N_SAMPLES))
        seed = inputs.get("seed", None)
        if seed is not None:
            seed = int(seed)

        if n_samples < 1:
            return {"error": "n_samples must be >= 1"}
        if n_samples > MAX_N_SAMPLES:
            return {
                "error": f"n_samples {n_samples} exceeds MAX_N_SAMPLES={MAX_N_SAMPLES}"
            }

        log.info(f"Generating {n_samples} samples (cancer_type={cancer_type}, seed={seed})")
        syn_df = self.model.generate(
            n_samples=n_samples,
            cancer_type=cancer_type,
            seed=seed,
            # No real_df_for_precision available at inference time; physical
            # constraints still apply via column_metadata baked into the bundle.
            real_df_for_precision=None,
            match_precision=False,
            enforce_constraints=True,
        )

        # ---- Serialize ----
        # JSON cannot represent np.int64 directly; cast everything to native types.
        records = _to_json_safe(syn_df.to_dict(orient="records"))
        return {
            "data":         records,
            "n_samples":    len(syn_df),
            "cancer_type":  cancer_type,
            "columns":      syn_df.columns.tolist(),
        }


# =========================================================================== #
#  Helpers                                                                    #
# =========================================================================== #

def _to_json_safe(obj):
    """Recursively convert numpy scalars / arrays into native Python types."""
    if isinstance(obj, dict):
        return {k: _to_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_to_json_safe(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, np.generic):
        return obj.item()
    if isinstance(obj, (pd.Timestamp,)):
        return obj.isoformat()
    if isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
        return None
    return obj


# =========================================================================== #
#  Local smoke test (not invoked by HF — convenience for the dev)             #
# =========================================================================== #

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Local smoke test for the HF handler")
    p.add_argument("--model-dir", required=True,
                   help="Directory containing model.pt (e.g. runs/breast_full)")
    p.add_argument("--cancer-type", default=None)
    p.add_argument("--n-samples", type=int, default=10)
    p.add_argument("--info", action="store_true", help="Just call info()")
    args = p.parse_args()

    handler = EndpointHandler(path=args.model_dir)
    if args.info:
        print(json.dumps(handler({"inputs": {"info": True}}), indent=2, default=str))
    else:
        out = handler({"inputs": {
            "cancer_type": args.cancer_type,
            "n_samples":   args.n_samples,
            "seed":        42,
        }})
        # Print summary not full data dump
        if "error" in out:
            print(json.dumps(out, indent=2))
        else:
            print(f"Returned {out['n_samples']} samples; columns:")
            print(f"  {out['columns']}")
            print(f"First sample:\n  {json.dumps(out['data'][0], indent=2, default=str)}")
